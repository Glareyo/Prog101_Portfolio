﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Runtime.InteropServices;
using System.Security.Policy;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Xml.Linq;
using TheMissingJewelMystery;

namespace TheMissingJewelMystery_Prototype1
{
    class PlayerInputController
    {
        public Room playerLocation;

        Player player;
        string playerInput;
        string playerName;
        

        string northCMD = ") = Go North ";
        string southCMD = ") = Go South ";
        string eastCMD = ") = Go East ";
        string westCMD = ") = Go West ";
        string examineCMD = ") = Inspect ";
        string openNoteBookCMD = ") = Open Notebook ";
        string talkCMD = ") = Talk ";
        string pickUpCMD = ") = Pick-up ";
        string checkInventoryCMD = ") = Check Inventory ";
        string interactCMD = ") = Interact";
        string markCMD = ") = Mark Item as Clue";

        public PlayerInputController(Player _player)
        {

            player = _player;
            playerName = player.name;
        }


        void CreateUIInterface()
        {
            CreateInterfaceBorder();

            //Console.WriteLine(interfaceCompass);
            InterfaceCompass();

            Console.Write($"{ColorRequiredInputPrompt(" N") + northCMD}");
            Console.Write($"{ColorRequiredInputPrompt(" S") + southCMD}");
            Console.Write($"{ColorRequiredInputPrompt(" E") + eastCMD}");
            Console.Write($"{ColorRequiredInputPrompt(" W") + westCMD}");
            Console.Write($"{ColorRequiredInputPrompt(" X") + examineCMD}");
            Console.Write($"{ColorRequiredInputPrompt(" O") + openNoteBookCMD}");
            
            Console.Write($"{ColorRequiredInputPrompt(" T") + talkCMD}");
            Console.Write($"{ColorRequiredInputPrompt(" P") + pickUpCMD}");
            Console.Write($"{ColorRequiredInputPrompt(" C") + checkInventoryCMD}");
            Console.Write($"{ColorRequiredInputPrompt(" I") + interactCMD}");
            Console.Write($"{ColorRequiredInputPrompt(" M") + markCMD}");


            Console.WriteLine("\n");


            CreateInterfaceBorder();

        }
        public string ActionPrompt()
        {
            string targetAction = "";
            do
            {
                CreateUIInterface();
                AskForInput("What do you want to do: ");
                playerInput = GetInput();
                try
                {
                    targetAction = Convert.ToString(playerInput[0]);
                }
                catch
                {
                    //Continue/Do nothing
                }
                

            } while (!ValidatePlayerInput(targetAction));

            //Check to see if player inputted a name alongside command
            



            return playerInput;
        }  //Initiate Action Prompt for player input. If valid, return input to program, then to player.
        public string ExamineActionPrompt(string _inputtedTarget)
        {
            if (_inputtedTarget !="") return CheckForCommandShortcut(_inputtedTarget);

            HighlightSelectedChoice("Examine", false);
            Console.WriteLine();
            Console.Write($"{ColorRequiredInputPrompt("room")} = inspect room");
            AskForInput("Input the name: ");
            playerInput = GetInput();

            return CheckForCommandShortcut(playerInput);
        }
        public string InteractActionPrompt(string _inputtedTarget)
        {
            if (_inputtedTarget != "") return CheckForCommandShortcut(_inputtedTarget);

            HighlightSelectedChoice("Interact", false);
            Console.WriteLine();
            AskForInput("Interact with (name): ");
            playerInput = GetInput();

            return CheckForCommandShortcut(playerInput);
        }
        public string PickUpActionPrompt(string _inputtedTarget)
        {
            if (_inputtedTarget != "") return CheckForCommandShortcut(_inputtedTarget);

            HighlightSelectedChoice("Pick-up", false);
            AskForInput("What do you want to pick up?\nInput the name: ");
            playerInput = GetInput();

            return CheckForCommandShortcut(playerInput);
        }
        public string TalkActionPrompt(string _inputtedTarget)
        {
            if (_inputtedTarget != "") return _inputtedTarget;
            HighlightSelectedChoice("Talk",false);
            AskForInput("Who do you want to talk to?\nInput Character's name: ");
            playerInput = GetInput();

            return playerInput;
        }
        public string MarkActionPrompt(string _inputtedTarget)
        {
            if (_inputtedTarget != "") return _inputtedTarget;

            HighlightSelectedChoice("Mark Item as Clue", false);
            Console.WriteLine();
            AskForInput("Input the name of the item: ");
            playerInput = GetInput();

            return playerInput;
        }
        
        
        
        
        public void OpenNoteBookPrompt()
        {
            Console.Clear();
            HighlightSelectedChoice("Open Notebook", false);

            // First Menu
            NotebookReviewMenu();
        }
        void NotebookReviewMenu()
        {
            bool exitOutOfMenu = false;
            int playerSelectedChoice = 0; //Stores the players selected choice in an int.
            

            while(!exitOutOfMenu)
            {
                bool inputInvalid = false; //Checks to see if the player put in an invalid input
                // First Menu
                CreateInterfaceBorder();
                ColorRequiredInputPrompt(" 0");
                Console.Write(") = Cancel");
                ColorRequiredInputPrompt(" 1");
                Console.Write(") = Review Observations");
                ColorRequiredInputPrompt(" 2");
                Console.Write(") = Review Statements");
                Console.WriteLine();
                CreateInterfaceBorder();

                AskForInput("Select a section: ");
                playerInput = GetInput();

                try
                {
                    playerSelectedChoice = Convert.ToInt16(playerInput);
                }
                catch
                {
                    inputInvalid = true;
                    InvalidInputWarning();
                }

                if (!inputInvalid)
                {
                    Console.Clear();
                    switch (playerSelectedChoice)
                    {
                        case 0:
                            exitOutOfMenu = true;
                            break;
                        case 1:;
                            NotebookClueEditMenu(player.noteBook.observationClues);
                            break;
                        case 2:
                            NotebookClueEditMenu(player.noteBook.statementClues);
                            break;
                        default:
                            inputInvalid = true;
                            InvalidInputWarning();
                            break;
                    }
                }

            }
        }
        void NotebookClueEditMenu(List<Clue> _listOfClues)
        {
            bool exitOutOfMenu = false;
            int playerSelectedChoice = 0; //Stores the players selected choice in an int.

            while(!exitOutOfMenu)
            {
                bool inputInvalid = false; //Checks to see if the player put in an invalid input
                player.noteBook.RevealClues(_listOfClues);


                // Clue Edit Menu
                CreateInterfaceBorder();
                ColorRequiredInputPrompt(" 0");
                Console.Write(") = Cancel");
                ColorRequiredInputPrompt(" 1");
                Console.Write(") = Remove Clue");
                Console.WriteLine();
                CreateInterfaceBorder();

                AskForInput("Select an Option: ");
                playerInput = GetInput();
                Console.Clear();

                try
                {
                    playerSelectedChoice = Convert.ToInt16(playerInput);
                }
                catch
                {
                    inputInvalid = true;
                    InvalidInputWarning();
                }

                if (!inputInvalid)
                {

                    Console.Clear();
                    switch (playerSelectedChoice)
                    {
                        case 0:
                            exitOutOfMenu = true;
                            break;
                        case 1: //Remove Clue Menu
                            NotebookRemoveClueMenu(_listOfClues);
                            break;
                        default:
                            inputInvalid = true;
                            InvalidInputWarning();
                            break;
                    }
                }


            }
            
        }
        void NotebookRemoveClueMenu(List<Clue> _listOfClues)
        {
            bool exitOutOfMenu = false;
            
            int playerSelectedChoice = 0; //Stores the players selected choice in an int.

            while(!exitOutOfMenu)
            {
                bool inputInvalid = false; //Checks to see if the player put in an invalid input
                player.noteBook.RevealClues(_listOfClues);
                // Remove Clue Menu
                CreateInterfaceBorder();
                ColorRequiredInputPrompt(" 0");
                Console.Write(") = Cancel");
                Console.WriteLine();
                CreateInterfaceBorder();
                AskForInput("Select the corresponding number of the clue: ");
                playerInput = GetInput();
                Console.Clear();

                try
                {
                    playerSelectedChoice = Convert.ToInt16(playerInput);
                }
                catch
                {
                    inputInvalid = true;
                    InvalidInputWarning();
                }

                if (!inputInvalid)
                {
                    Console.Clear();
                    if (playerSelectedChoice == 0)
                        exitOutOfMenu = true;
                    else
                    {
                        try
                        {
                            string isValid = _listOfClues[playerSelectedChoice-1].clueName;
                            NotebookConfirmRemovalMenu(playerSelectedChoice, _listOfClues);
                        }
                        catch
                        {
                            inputInvalid = true;
                            InvalidInputWarning();
                        }
                    }


                }
            }
            
        }
        public void NotebookConfirmRemovalMenu(int _targetClueNumber, List<Clue> _listOfClues)
        {
            bool exitOutOfMenu = false;

            int playerSelectedChoice = 0; //Stores the players selected choice in an int.

            while (!exitOutOfMenu)
            {
                bool inputInvalid = false; //Checks to see if the player put in an invalid input
                NotebookHighlightSelectedClue(_targetClueNumber - 1, _listOfClues);
                
                // Remove Clue Menu
                CreateInterfaceBorder();
                ColorRequiredInputPrompt(" 0");
                Console.Write(") = No");
                ColorRequiredInputPrompt(" 1");
                Console.Write(") = Yes");
                Console.WriteLine();
                CreateInterfaceBorder();
                AskForInput("Confirm Removal?: ");
                playerInput = GetInput();
                Console.Clear();

                try
                {
                    playerSelectedChoice = Convert.ToInt16(playerInput);
                }
                catch
                {
                    inputInvalid = true;
                    InvalidInputWarning();
                }

                if (!inputInvalid)
                {
                    Console.Clear();
                    if (playerSelectedChoice == 0)
                        exitOutOfMenu = true;
                    else
                    {
                        try
                        {
                            player.noteBook.RemoveClue(playerSelectedChoice - 1, _listOfClues);
                            exitOutOfMenu = true;
                        }
                        catch
                        {
                            inputInvalid = true;
                            InvalidInputWarning();
                        }
                    }


                }
            }
        }
        public void NotebookHighlightSelectedClue(int selectedNumber, List<Clue> _listOfClues)
        {
            const string OBSERVATION = "Observation";
            const string STATEMENT = "Statement";
            int number = 1;

            for (int i = 0; i < _listOfClues.Count; i++)
            {
                Clue clue = _listOfClues[i];

                if (i == selectedNumber)
                {
                    Console.ForegroundColor = ConsoleColor.White;
                    Console.BackgroundColor = ConsoleColor.DarkRed;
                }
                if (clue.clueType == STATEMENT)
                {
                    Console.WriteLine($" {number}) {clue.personStatementBy}  :  {clue.clueSummary}");
                }
                else Console.WriteLine($" {number}) {clue.clueName}  :  {clue.clueSummary}");
                number++;

                Console.ResetColor();
            }
        }

        public void AskQuestionsActionPrompt(Character _targetCharacter)
        {
            Question previousQuestion = null;
            while (true)
            {
                HighlightSelectedChoice(_targetCharacter.name, true);
                CreateInterfaceBorder();
                Console.Write(" Available Questions For: ");
                Console.WriteLine(ColorCharacterName(_targetCharacter.name));
                CreateInterfaceBorder();

                Console.WriteLine(" M) Mark as Clue");
                Console.WriteLine(" 0) Cancel");
                _targetCharacter.RevealAvailableQuestions(player.noteBook.loggedClues);

                AskForInput("Select a question via #...\nNumber: ");
                playerInput = GetInput();

                if (playerInput.ToLower() == "m")
                {
                    MarkAsClue(previousQuestion);
                }
                else
                {
                    try
                    {
                        int selectedQuestion;
                        selectedQuestion = Convert.ToInt16(playerInput);


                        if (selectedQuestion > _targetCharacter.availableQuestions.Count)
                        {
                            InvalidInputWarning();
                        }
                        else if (selectedQuestion == 0)
                        {
                            Console.Clear();
                            break;
                        }
                        else
                        {
                            selectedQuestion--;
                            string questionPrompt = _targetCharacter.availableQuestions[selectedQuestion].questionPrompt;
                            string characterName = _targetCharacter.name;
                            string answerPrompt = _targetCharacter.availableQuestions[selectedQuestion].GiveAnswer();

                            Dialog(playerName, questionPrompt);
                            Dialog(characterName, answerPrompt);
                            Console.WriteLine();
                            previousQuestion = _targetCharacter.availableQuestions[selectedQuestion];


                        }
                    }
                    catch
                    {
                        InvalidInputWarning();
                    }
                }
            }
        }




 
        
        
        public void MarkAsClue(Question question)
        {
            
            Console.Clear();
            if (question != null)
            {
                player.noteBook.AddClue(question.clue);
                Console.Write($"{question.clue.clueType} Marked: {question.questionPrompt} by ");
                ObjectColors.PersonColor(question.clue.personStatementBy);
                Console.WriteLine();
                Console.WriteLine($"Clue: {question.clue.clueSummary}");
                
            }
            else Console.WriteLine("You must ask the question first...");
        }
        public void MarkAsClue(Item item)
        {
            player.noteBook.AddClue(item.clue);
            //Add to player's Notebook of Clues 
            Console.Write($"{item.clue.clueType} Marked: ");
            ObjectColors.ItemColor(item.name);
            Console.WriteLine();
            Console.WriteLine($"Clue: {item.clue.clueSummary}");
            
        }


        public List<Item> InteractingWithItemContainer(Item _targetItem, List<Item> _playerInventory)
        {
            string playerInput;
            int selectedInput = 0;
            List<Item> playerInventory = _playerInventory;
            List<Item> tempInventoryItems = new List<Item>();

            foreach (Item item in playerInventory)
            {
                if (item != _targetItem) tempInventoryItems.Add(item);
            }

            const int CANCEL = 0;
            const int OPEN_OR_UNLOCK = 1;
            const int PLACE = 2;
            const int REMOVE = 3;


            //Print options out for 
            HighlightSelectedChoice(_targetItem.name, false);
            Console.WriteLine(_targetItem.interactDescription);

            if (_targetItem.isLocked)
            {
                Console.Write($"The ");
                ObjectColors.ItemColor(_targetItem.name);
                Console.Write(" is ");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("LOCKED");
                Console.ResetColor();
            }

            //Show possible commands
            ColorRequiredInputPrompt(" 0");
            Console.WriteLine(") Cancel");

            ColorRequiredInputPrompt(" 1");
            if (_targetItem.isLocked)
            {
                Console.WriteLine(") Unlock");
            }
            else
            {
                Console.WriteLine(") Open");
                ColorRequiredInputPrompt(" 2");
                Console.WriteLine(") Place item");
                ColorRequiredInputPrompt(" 3");
                Console.WriteLine(") Remove item");
            }

            //Prompt player
            AskForInput("What do you want to do: ");

            try
            {
                selectedInput = Convert.ToInt32(GetInput());
                switch (selectedInput)
                {
                    case CANCEL:
                        Console.Clear();
                        break;
                    case OPEN_OR_UNLOCK:
                        if (_targetItem.isLocked)
                        {
                            while (true)
                            {
                                int i = 1;
                                int selectedItem = 0;

                                Console.ForegroundColor = ConsoleColor.Yellow;
                                Console.WriteLine("This requires an item to unlock...");
                                Console.ResetColor();

                                Console.WriteLine($"{ColorRequiredInputPrompt(" 0")}) Cancel");
                                foreach (Item item in tempInventoryItems)
                                {
                                    string temp = " ";
                                    temp += Convert.ToString(i);

                                    Console.WriteLine($"{ColorRequiredInputPrompt(temp)}) {item.name}");
                                    i++;
                                }

                                AskForInput("Select an item to use: ");
                                try
                                {
                                    selectedItem = Convert.ToInt16(GetInput());
                                    Console.Clear();
                                    if (selectedItem == 0) break;
                                    else
                                    {
                                        HighlightSelectedChoice(tempInventoryItems[selectedItem - 1].name, false);
                                        bool currentState = _targetItem.isLocked;
                                        _targetItem.UnlockContainer(tempInventoryItems[selectedItem - 1]);

                                        if (currentState != _targetItem.isLocked) break;
                                    }
                                }
                                catch
                                {
                                    Console.Clear();
                                    InvalidInputWarning();
                                }
                            }
                        }
                        else
                        {
                            Console.Clear();
                            _targetItem.OpenContainer();
                        }
                        break;
                    case PLACE:
                        Console.Clear();
                        if (_targetItem.isLocked)
                        {
                            InvalidInputWarning();
                            break;
                        }

                        while (true)
                        {
                            int i = 1;
                            int selectedItemNum = 0;

                            Item selectedItem;

                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.WriteLine("Select an item to place...");
                            Console.ResetColor();

                            Console.WriteLine($"{ColorRequiredInputPrompt(" 0")}) Cancel");


                            foreach (Item item in tempInventoryItems)
                            {
                                string temp = " ";
                                temp += Convert.ToString(i);

                                Console.WriteLine($"{ColorRequiredInputPrompt(temp)}) {item.name}");
                                i++;
                            }

                            AskForInput("Select an item to place: ");
                            try
                            {
                                selectedItemNum = Convert.ToInt16(GetInput());
                                Console.Clear();
                                if (selectedItemNum == 0) break;
                                else
                                {

                                    selectedItem = tempInventoryItems[selectedItemNum - 1];
                                    HighlightSelectedChoice(selectedItem.name, false);
                                    bool removeItem = _targetItem.PlaceItemInside(selectedItem);

                                    if (removeItem)
                                    {
                                        tempInventoryItems.Remove(selectedItem);
                                        playerInventory.Remove(selectedItem);
                                    }
                                    
                                    
                                }
                            }
                            catch
                            {
                                Console.Clear();
                                InvalidInputWarning();
                            }
                        }
                        break;
                    case REMOVE:
                        Console.Clear();
                        if (_targetItem.isLocked)
                        {
                            InvalidInputWarning();
                            break;
                        }
                        while (true)
                        {
                            int i = 1;
                            int selectedItem = 0;

                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.WriteLine("Select an item to remove...");
                            Console.ResetColor();

                            Console.WriteLine($"{ColorRequiredInputPrompt(" 0")}) Cancel");
                            foreach (Item item in _targetItem.containedItems)
                            {
                                string temp = " ";
                                temp += Convert.ToString(i);

                                Console.WriteLine($"{ColorRequiredInputPrompt(temp)}) {item.name}");
                                i++;
                            }

                            AskForInput("Select an item to remove: ");
                            playerInput = GetInput();
                            Console.WriteLine(playerInput);
                            try
                            {

                                selectedItem = Convert.ToInt16(playerInput);

                                Console.Clear();
                                if (selectedItem == 0) break;
                                else
                                {
                                    HighlightSelectedChoice(_targetItem.containedItems[selectedItem - 1].name, false);
                                    playerInventory.Add(_targetItem.containedItems[selectedItem - 1]);
                                    _targetItem.RemoveItemInside(_targetItem.containedItems[selectedItem - 1]);

                                }
                            }
                            catch
                            {
                                //Console.Clear();
                                InvalidInputWarning();
                            }
                        }

                        break;
                    default:
                        InvalidInputWarning();
                        break;
                }
            }
            catch
            {
                InvalidInputWarning();
                InteractingWithItemContainer(_targetItem, playerInventory);
            }

            //Reset if not canceled
            if (selectedInput != CANCEL) InteractingWithItemContainer(_targetItem, playerInventory);
            return playerInventory;
        }
      
        
        public void InteractingWithDoor(Door door,List<Item> playerInventory)
        {
            string _prompt = "What do you want to do: ";
            string _input;
            int _selectedOption = 0;
            const int CANCEL = 0;
            const int OPENCLOSE = 1;
            const int LOCKING = 2;
            const int LOOKTHROUGH = 3;

            string _cancelOptionString = "Cancel";
            string _lookThroughOptionString = "Look Through";
            string _openCloseOptionString;
            string _lockingOptionString;


            //Tell player what door it is
            HighlightSelectedChoice(door.name, false);
            CreateInterfaceBorder();
            Console.Write($" Interacting with: ");
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.WriteLine(door.name);
            Console.ResetColor();
            CreateInterfaceBorder();

            Console.WriteLine($"This is the {door.name}");

            //Tell player if it is open or closed
            if (door.isOpen) Console.WriteLine("It is open.");
            else Console.WriteLine("It is closed.");

            //Add open close option
            if (door.isOpen) _openCloseOptionString = "Close";
            else _openCloseOptionString = "Open";
            
            //If islocked, Add unlockLock option.
            if (door.isLocked) _lockingOptionString = "Unlock";
            else _lockingOptionString = "Lock";

            Console.WriteLine($"{ColorRequiredInputPrompt(" 0")}) {_cancelOptionString}");
            Console.WriteLine($"{ColorRequiredInputPrompt(" 1")}) {_openCloseOptionString}");
            Console.WriteLine($"{ColorRequiredInputPrompt(" 2")}) {_lockingOptionString}");
            Console.WriteLine($"{ColorRequiredInputPrompt(" 3")}) {_lookThroughOptionString}");

            //Prompt player for input.
            AskForInput(_prompt);
            _input = GetInput();

            //Attempt to validate door.
            try
            {
                _selectedOption = Convert.ToInt16(_input);
            }
            catch
            {
                Console.Clear();
                InvalidInputWarning();
                InteractingWithDoor(door, playerInventory);
            }

            Console.Clear();
            switch(_selectedOption)
            {
                case CANCEL:
                    break;
                case OPENCLOSE:
                    HighlightSelectedChoice(_openCloseOptionString, false);
                    door.ChangeOpenState();
                    break;
                case LOCKING:
                    HighlightSelectedChoice(_lockingOptionString, false);
                    #region Locking and unlocking
                    if (door.isOpen) Console.WriteLine("The door must be closed to lock the door.");
                    //Check to see if the door cannot be locked and is currently unlocked.
                    else if (door.isLocked == false && door.lockable == false)
                    {
                        Console.WriteLine("This door cannot be locked.");
                    }
                    //See if the door can lock and there is no key, OR if the door is locked, and it doesn't require a key to unlock
                    else if ((door.lockable && door.key == null)||(door.isLocked && door.key == null))
                    {
                        door.ChangeLockState(door.key);
                    }
                    else
                    {
                        while (true)
                        {
                            int i = 1;
                            int selectedItem = 0;

                            Console.ForegroundColor = ConsoleColor.Yellow;
                            Console.WriteLine("This requires an item to unlock...");
                            Console.ResetColor();

                            Console.WriteLine($"{ColorRequiredInputPrompt(" 0")}) Cancel");
                            foreach (Item item in playerInventory)
                            {
                                string temp = " ";
                                temp += Convert.ToString(i);

                                Console.WriteLine($"{ColorRequiredInputPrompt(temp)}) {item.name}");
                                i++;
                            }

                            AskForInput("Select an item to use: ");
                            try
                            {
                                selectedItem = Convert.ToInt16(GetInput());
                                Console.Clear();
                                if (selectedItem == CANCEL) break;
                                else
                                {
                                    HighlightSelectedChoice(playerInventory[selectedItem - 1].name, false);
                                    bool currentState = door.isLocked;
                                    door.ChangeLockState(playerInventory[selectedItem - 1]);
                                    
                                    if (currentState != door.isLocked) break;
                                }
                            }
                            catch
                            {
                                Console.Clear();
                                InvalidInputWarning();
                            }
                        }
                    }
                    #endregion
                    break;
                case LOOKTHROUGH:
                    HighlightSelectedChoice(_lookThroughOptionString, false);
                    if (door.isClear)
                    {
                        Console.Write("The room ahead is the ");
                        if (playerLocation.northDoor.doorID == door.doorID) playerLocation.northRoom.GiveDescription();
                        else if (playerLocation.southDoor.doorID == door.doorID) playerLocation.southRoom.GiveDescription();
                        else if (playerLocation.eastDoor.doorID == door.doorID) playerLocation.eastRoom.GiveDescription();
                        else if (playerLocation.westDoor.doorID == door.doorID) playerLocation.westRoom.GiveDescription();
                    }
                    else Console.WriteLine("Unable to look through");
                    break;
                default:
                    InvalidInputWarning();
                    break;
            };
            if (_selectedOption != CANCEL) InteractingWithDoor(door, playerInventory);
        }
        

        
        void DisplayMenu(string title, string[] _options)
        {
            CreateInterfaceBorder();
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(" " + title);
            Console.ResetColor();
            CreateInterfaceBorder();
            Console.WriteLine();

            for (int i = 0; i < _options.Length; i++)
            {
                ColorRequiredInputPrompt(" " + i);
                Console.WriteLine($") " + _options[i]);
            }
            Console.WriteLine();
        }

        public void InteractingWithVan()
        {
            bool exitMenu = false;
            int playerInput = 0;
            string[] options =
            {
                "Cancel",
                "Suspects",
                "Items"
            };

            while(!exitMenu)
            {
                HighlightSelectedChoice(PoliceVan.name, false);
                DisplayMenu("Interacting with: " + PoliceVan.name, options);

                AskForInput("Input a number: ");
                try
                {
                    playerInput = Convert.ToInt32(GetInput());
                    Console.Clear();
                    switch (playerInput)
                    {
                        case 0:
                            exitMenu = true;
                            break;
                        case 1:
                            Van_AllSuspectsMenu();
                            break;
                        case 2:
                            Van_ItemsInVanMenu();
                            break;
                        default:
                            InvalidInputWarning();
                            break;
                    }
                }
                catch
                {
                    Console.Clear();

                    InvalidInputWarning();
                }
            }


        }
        
        void Van_ItemsInVanMenu()
        {
            bool exitMenu = false;
            int playerInput = 0;
            string[] options =
            {
                "Cancel",
                "Add Item",
                "Remove Item",
            };

            while(!exitMenu)
            {
                HighlightSelectedChoice("Items inside van", false);
                DisplayMenu("Items inside van", options);
                PoliceVan.DisplayAllHeldItems();

                AskForInput("Input the corresponding number: ");

                try
                {
                    playerInput = Convert.ToInt32(GetInput());
                    Console.Clear();

                    if (playerInput == 0) exitMenu = true;
                    else if (playerInput == 1) Van_AddItemToVanMenu();
                    else if (playerInput == 2) Van_RemoveItemInVanMenu();//Remove Suspect
                    else
                        InvalidInputWarning();
                }
                catch
                {
                    Console.Clear();

                    InvalidInputWarning();
                }
            }
        }
        void Van_RemoveItemInVanMenu()
        {
            bool exitMenu = false;
            int playerInput = 0;
            string[] options;
            string[] standardOptions = { "Cancel" };

            //Get the entire list of characters.
            //Compare to list of suspects and remove them from the list if they are already a suspect.


            while (!exitMenu)
            {
                HighlightSelectedChoice("Removing Items", false);



                //Set options
                options = new string[standardOptions.Length + PoliceVan.containedItems.Count];
                options[0] = standardOptions[0];
                for (int i = 0; i < PoliceVan.containedItems.Count; i++)
                {
                    options[i + 1] = PoliceVan.containedItems[i].name;
                }

                CreateInterfaceBorder();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(" Removing Items");
                Console.ResetColor();
                CreateInterfaceBorder();

                ColorRequiredInputPrompt(" " + 0);
                Console.WriteLine($") {options[0]}");
                for (int i = 1; i < options.Length; i++)
                {
                    ColorRequiredInputPrompt(" " + i);
                    Console.Write($") ");
                    ObjectColors.ItemColor(options[i]);
                    Console.WriteLine();
                }


                //Begin input
                AskForInput("Input the number corresponding to the item: ");

                try
                {
                    playerInput = Convert.ToInt32(GetInput());
                    Console.Clear();

                    if (playerInput == 0) exitMenu = true;
                    else if (playerInput < options.Length && playerInput > 0)
                    {
                        player.inventory.Add(PoliceVan.containedItems[playerInput - 1]);

                        PoliceVan.RemoveItem(playerInput - 1);
                    }
                    else InvalidInputWarning();

                }
                catch
                {
                    Console.Clear();
                    InvalidInputWarning();
                }
            }
        }
        void Van_AddItemToVanMenu()
        {
            bool exitMenu = false;
            int playerInput = 0;
            string[] options;
            string[] standardOptions = { "Cancel" };
            
            while (!exitMenu)
            {
                HighlightSelectedChoice("Adding Item to Van", false);
                options = new string[standardOptions.Length + player.inventory.Count];
                options[0] = standardOptions[0];
                for (int i = 0; i < player.inventory.Count; i++)
                {
                    options[i + 1] = player.inventory[i].name;
                }

                DisplayMenu("Adding Item to Van", options);


                AskForInput("Input the number corresponding to the item: ");

                try
                {
                    playerInput = Convert.ToInt32(GetInput());
                    Console.Clear();

                    if (playerInput == 0) exitMenu = true;
                    else if (playerInput < options.Length && playerInput > 0)
                    {

                        PoliceVan.AddItem(player.inventory[playerInput-1]);
                        player.inventory.RemoveAt(playerInput - 1);

                    }
                    else InvalidInputWarning();

                }
                catch
                {
                    Console.Clear();
                    InvalidInputWarning();
                }

            }
        }

        void Van_AllSuspectsMenu()
        {
            bool exitMenu = false;
            int playerInput = 0;
            string[] options = { "Cancel", //Index 0
                "Add Suspect", //Index 1
                "Remove Suspect" //Index 2
            };

            while (!exitMenu)
            {
                HighlightSelectedChoice("Suspects", false);
                DisplayMenu("List of Suspects", options);


                PoliceVan.DisplayAllSuspects();

                AskForInput("Input the corresponding number: ");

                try
                {
                    playerInput = Convert.ToInt32(GetInput());
                    Console.Clear();

                    if (playerInput == 0) exitMenu = true;
                    else if (playerInput == 1) Van_AddSuspectMenu();
                    else if (playerInput == 2) Van_RemoveSuspectMenu(); //Remove Suspect
                    else
                        InvalidInputWarning();
                }
                catch
                {
                    Console.Clear();

                    InvalidInputWarning();
                }
            }
        }
        void Van_RemoveSuspectMenu()
        {
            bool exitMenu = false;
            int playerInput = 0;
            string[] options;
            string[] standardOptions = { "Cancel" };
            
            //Get the entire list of characters.
            //Compare to list of suspects and remove them from the list if they are already a suspect.


            while (!exitMenu)
            {
                HighlightSelectedChoice("Removing Suspects", false);

                
                
                //Set options
                options = new string[standardOptions.Length + PoliceVan.suspects.Count];
                options[0] = standardOptions[0];
                for (int i = 0; i < PoliceVan.suspects.Count; i++)
                {
                    options[i + 1] = PoliceVan.suspects[i];
                }

                CreateInterfaceBorder();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(" Removing Suspects");
                Console.ResetColor();
                CreateInterfaceBorder();

                ColorRequiredInputPrompt(" " + 0);
                Console.WriteLine($") {options[0]}");
                for (int i = 1; i < options.Length; i++)
                {
                    ColorRequiredInputPrompt(" " + i);
                    Console.Write($") ");
                    ObjectColors.PersonColor(options[i]);
                    Console.WriteLine();
                }


                //Begin input
                AskForInput("Input the number corresponding to the option: ");

                try
                {
                    playerInput = Convert.ToInt32(GetInput());
                    Console.Clear();

                    if (playerInput == 0) exitMenu = true;
                    else if (playerInput < options.Length && playerInput > 0) PoliceVan.RemoveSuspect(options[playerInput]);
                    else InvalidInputWarning();

                }
                catch
                {
                    Console.Clear();
                    InvalidInputWarning();
                }
            }
        }
        void Van_AddSuspectMenu()
        {
            bool exitMenu = false;
            int playerInput = 0;
            string[] options;
            string[] standardOptions = { "Cancel" };
            List<Character> possibleSuspects = new List<Character>();
 
            //Get the entire list of characters.
            //Compare to list of suspects and remove them from the list if they are already a suspect.
            

            while(!exitMenu)
            {
                HighlightSelectedChoice("Adding Suspects", false);

                possibleSuspects.Clear();
                foreach (Character character in AllCharacterObjects.allCharacters)
                {
                    if (character.name == "Michelle")
                    {
                        //continue
                    }
                    else if (character.name == "Officer Michelle")
                    {
                        //continue
                    }
                    else
                    {
                        bool suspectAlreadyMarked = false;
                        foreach (string suspect in PoliceVan.suspects)
                        {
                            if (character.name == suspect)
                            {
                                suspectAlreadyMarked = true;
                            }
                        }

                        //if the character is not on the list
                        if (suspectAlreadyMarked == false)
                        {
                            possibleSuspects.Add(character);
                        }
                    }

                }
                //Set options
                options = new string[standardOptions.Length + possibleSuspects.Count];
                options[0] = standardOptions[0];
                for (int i = 0; i < possibleSuspects.Count; i++)
                {
                    options[i+1] = possibleSuspects[i].name;
                }

                CreateInterfaceBorder();
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(" Adding Suspects");
                Console.ResetColor();
                CreateInterfaceBorder();

                ColorRequiredInputPrompt(" " + 0);
                Console.WriteLine($") {options[0]}");
                for (int i = 1; i < options.Length; i++)
                {
                    ColorRequiredInputPrompt(" " + i);
                    Console.Write($") ");
                    ObjectColors.PersonColor(options[i]);
                    Console.WriteLine();
                }
                //Begin input
                AskForInput("Input the number corresponding to the option: ");

                try
                {
                    playerInput = Convert.ToInt32(GetInput());
                    Console.Clear();

                    if (playerInput == 0) exitMenu = true;
                    else if (playerInput < options.Length && playerInput > 0) PoliceVan.AddSuspect(possibleSuspects[playerInput - 1]);
                    else InvalidInputWarning();

                }
                catch
                {
                    Console.Clear();
                    InvalidInputWarning();
                }
            }



        }



        void HighlightSelectedChoice(string actionChosenPrompt, bool talking)
        {
            Console.WriteLine();
            Console.ForegroundColor = ConsoleColor.Yellow;
            if (talking) Console.WriteLine($"----Talking to {actionChosenPrompt}----");
            else Console.WriteLine($"----{actionChosenPrompt} Selected----");
            Console.ResetColor();
        }
        string ColorRequiredInputPrompt(string _inputOption)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write(_inputOption);
            Console.ResetColor();
            return null;
        }        
        string ColorCharacterName(string _name)
        {
            if (_name == playerName) Console.ForegroundColor = ConsoleColor.Yellow;
            else Console.ForegroundColor = ConsoleColor.Cyan;

            Console.Write(_name);
            Console.ResetColor();
            
            return null;
        }
        
        
        string CheckForCommandShortcut(string _input)
        {
            string[] northDoorCommands = { "n door", "north door", "north", "n" };
            string[] southDoorCommands = { "s door", "south door", "south", "s" };
            string[] eastDoorCommands = { "e door", "east door", "east", "e" };
            string[] westDoorCommands = { "w door", "west door", "west", "w" };

            List<string> AllCommands = new List<string>();

            foreach (string CMD in northDoorCommands) if (_input == CMD) _input = playerLocation.northDoor.name;
            foreach (string CMD in southDoorCommands) if (_input == CMD) _input = playerLocation.southDoor.name;
            foreach (string CMD in eastDoorCommands) if (_input == CMD) _input = playerLocation.eastDoor.name;
            foreach (string CMD in westDoorCommands) if (_input == CMD) _input = playerLocation.westDoor.name;


            return _input.ToLower();
        }
        void AskForInput(string _prompt)
        {
            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write($"\n{_prompt}");
            Console.ResetColor();
        } // Ask player for input
        string GetInput()
        {
            string input = "";


            input = Console.ReadLine();
            input = input.ToLower();

            return input;
        } // Get player input




        void Dialog(string _name,string _phrase)
        {
            Console.Write("\n ");
            Console.Write($"{ColorCharacterName(_name)} : ");
            
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"\"{_phrase}\"");
            Console.ResetColor();
        }
        bool ValidatePlayerInput(string input)
        {
            switch (input)
            {
                case "n":
                    return true;
                case "s":
                    return true;
                case "e":
                    return true;
                case "w":
                    return true;
                case "u":
                    return true;
                case "d":
                    return true;
                case "x":
                    return true;
                case "t":
                    return true;
                case "p":
                    return true;
                case "o":
                    return true;
                case "c":
                    return true;
                case "i":
                    return true;
                case "m":
                    return true;
                default:
                    InvalidInputWarning();
                    return false;
            } //Validate the input of the player.
        } //Validate Player Input
        void CreateInterfaceBorder()
        {
            for (int i = 0; i < Console.WindowWidth; i++)
            {
                Console.Write("-");
            }
        }
        void InvalidInputWarning()
        {
            Console.Beep();
            Console.Clear();
            Console.BackgroundColor = ConsoleColor.Red;
            Console.WriteLine("INVALID INPUT");
            Console.ResetColor();
        } //Warn player of invalid input


        void InterfaceCompass()
        {
            string westEastSection = " W --+-- E ";
            string westSection = "--";
            string eastSection = "--";
            int tempDist = (Console.WindowWidth/2)-(westEastSection.Length/2);
            string north = playerLocation.northRoom.name;
            string south = playerLocation.southRoom.name;
            string east = playerLocation.eastRoom.name;
            string west = playerLocation.westRoom.name;

            Door nDoor = playerLocation.northDoor;
            Door sDoor = playerLocation.southDoor;
            Door eDoor = playerLocation.eastDoor;
            Door wDoor = playerLocation.westDoor;


            string interfaceCompass = $@"
     N
     |       
 W ----- E
     |
     S
";

            Console.WriteLine();

            CompassRoomColor(north);
            Console.WriteLine(CenterString(north));

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(CenterString("N")); 
            Console.Write(CenterString(""));
            CompassDrawDoorWithColor(nDoor, "|");
            Console.WriteLine();
            for (int i = 0; i < tempDist-west.Length; i++)
            {
                Console.Write(" ");
            }
            CompassRoomColor(west);
            Console.Write(west);

            Console.ForegroundColor = ConsoleColor.White;
            Console.Write(" W ");
            
 
            CompassDrawDoorWithColor(wDoor, westSection);

            Console.Write("+");

            CompassDrawDoorWithColor(eDoor, eastSection);

            Console.Write(" E ");
            CompassRoomColor(east);
            Console.WriteLine(east);

            Console.ForegroundColor = ConsoleColor.White;
            Console.Write(CenterString(""));
            CompassDrawDoorWithColor(sDoor, "|");
            Console.WriteLine();
            Console.WriteLine(CenterString("S"));

            CompassRoomColor(south);
            Console.WriteLine(CenterString(south));

            Console.WriteLine();
            Console.ResetColor();

        }
        void CompassRoomColor(string _roomName)
        {
            if (_roomName == "/") Console.ForegroundColor = ConsoleColor.Gray;
            else Console.ForegroundColor = ConsoleColor.Magenta;
        }
        void CompassDrawDoorWithColor(Door _door, string _compassArm)
        {
            if (_door.isDoor)
            {
                if (_door.isOpen) Console.BackgroundColor = ConsoleColor.Green;
                else if (_door.isOpen == false)
                {
                    if (_door.isLocked) Console.BackgroundColor = ConsoleColor.Red;
                    else if (_door.isLocked == false) Console.BackgroundColor = ConsoleColor.Yellow;
                }
            }
            else Console.BackgroundColor = ConsoleColor.Black;

            Console.Write(_compassArm);
            Console.ResetColor();
        }

        string CenterString(string _string)
        {
            string centeredString = "";

            for (int i = 0; i < (Console.WindowWidth / 2)-(_string.Length/2); i++)
            {
                centeredString += " ";
            }
            centeredString += _string;
            return centeredString;
        }
    }
}
