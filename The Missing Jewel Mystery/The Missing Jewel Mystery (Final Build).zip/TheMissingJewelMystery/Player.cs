﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TheMissingJewelMystery;

namespace TheMissingJewelMystery_Prototype1
{
    internal class Player
    {
        public string name;
        public List<Item> inventory = new List<Item>();
        public PlayerInputController playerInputController;
        public Room currentLocation;
        public NoteBook noteBook;
        //Change
        public string targetInputAction;
        public string playerInput;

        public Player(string _name)
        {
            name = _name;
            playerInputController = new PlayerInputController(this);
            noteBook = new NoteBook();
        }


        public void PlayerAction()
        {
            playerInputController.playerLocation = currentLocation;

            string target = "";
            string input = playerInputController.ActionPrompt();

            //Return input
            //Grab the first char of input
            targetInputAction = Convert.ToString(input[0]);
            
            //See if player has entered a name alongside with action
            if (input.Length > 1)
            {
                int targetNameChar = 1;
                for (int i = 1; i < input.Length; i++)
                {
                    if (input[i] != ' ') break;
                    else targetNameChar++;
                }
                for (int s = targetNameChar; s < input.Length; s++)
                {
                    target += input[s];
                }
            }

            

            Console.WriteLine($"The target is {target}");

            switch (targetInputAction)
            {
                case "m":
                    MarkItemAsClue(target);
                    break;
                case "n":
                    Move(targetInputAction);
                    break;
                case "s":
                    Move(targetInputAction);
                    break;
                case "e":
                    Move(targetInputAction);
                    break;
                case "w":
                    Move(targetInputAction);
                    break;
                case "x":
                    Examine(target);
                    break;
                case "t":
                    Talk(target);
                    break;
                case "p":
                    PickUp(target);
                    break;
                case "o":
                    OpenPlayersNoteBook();
                    break;
                case "c":
                    CheckInventory();
                    break;
                case "i":
                    Interact(target);
                    break;
            }
        }
        void Move(string _input)
        {
            Console.Clear();
            Room targetRoom = null;
            Door targetDoor = null;
            string targetDirection = "";
            string[] direction = { "North", "South", "East", "West" };
            switch (_input)
            {
                case "n":
                    targetRoom = currentLocation.northRoom;
                    targetDoor = currentLocation.northDoor;
                    targetDirection = direction[0];
                    break;
                case "s":
                    targetRoom = currentLocation.southRoom;
                    targetDoor = currentLocation.southDoor;
                    targetDirection = direction[1];
                    break;
                case "e":
                    targetRoom = currentLocation.eastRoom;
                    targetDoor = currentLocation.eastDoor;
                    targetDirection = direction[2];
                    break;
                case "w":
                    targetRoom = currentLocation.westRoom;
                    targetDoor = currentLocation.westDoor;
                    targetDirection = direction[3];
                    break;
            }
            
            if (targetRoom.roomID == " ")
            {
                Console.WriteLine("You cannot go that way."); 
            }
            else if (targetDoor.isOpen == false)
            {
                Console.WriteLine("The door is closed.");
            }
            else
            {
                Console.WriteLine("You go " + targetDirection);
                currentLocation = targetRoom;
            }
            Console.Write("You are now in the ");
            currentLocation.GiveDescription();



        }
       
        void MarkItemAsClue(string _target)
        {
            playerInput = "";
            Item targetItem;


            //Check to see if payer inputted additional information regarding the target action, see if it is "";
            playerInput = playerInputController.MarkActionPrompt(_target);
            
            Console.Clear();
            targetItem = CheckItemsInCurrentLocation(playerInput);

            if (targetItem != null)
            {
                playerInputController.MarkAsClue(targetItem);
            }
            else
            {
                Console.WriteLine($"There is no {playerInput} here...");
            }
        }
        void Examine(string _target)
        {
            playerInput = "";
            Character targetCharacter;
            Item targetItem;
            Door targetDoor;


            //Check to see if payer inputted additional information regarding the target action, see if it is "";
            playerInput = playerInputController.ExamineActionPrompt(_target);

            Console.Clear();
            targetCharacter = CheckCharactersInCurrentLocation(playerInput);
            targetItem = CheckItemsInCurrentLocation(playerInput);
            targetDoor = CheckDoorsInCurrentLocation(playerInput);
            
            if (playerInput == "room")
            {
                Console.Write("You are in the ");
                currentLocation.GiveDescription();
            }
            else if (playerInput == PoliceVan.name.ToLower())
            {
                if (this.currentLocation.roomID != PoliceVan.location.roomID)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("The  ");
                    ObjectColors.PoliceVanName();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" is not here.");
                    Console.ResetColor();
                }
                else
                {
                    Console.Write("The ");
                    ObjectColors.PoliceVanName();
                    Console.Write($" is here, {PoliceVan.currentState}");
                }
            }
            else if (targetCharacter != null)
            {
                ObjectColors.PersonColor(targetCharacter.name);
                Console.WriteLine($" is {targetCharacter.currentState}.");
                Console.WriteLine(targetCharacter.description);
            }
            else if (targetItem != null)
            {
                if (targetItem.location != AllRoomObjects.GiveRoom(" "))
                {
                    Console.Write("This is a ");
                    ObjectColors.ItemColor(targetItem.name);
                    Console.Write(" " + targetItem.currentState);
                    Console.WriteLine();
                }
                else
                {
                    Console.Write("This is a ");
                    ObjectColors.ItemColor(targetItem.name);
                    Console.WriteLine();
                }
                Console.WriteLine(targetItem.description);
            }
            else if (targetDoor != null)
            {
                if (targetDoor.doorID == " ")
                {
                    Console.WriteLine("There is no door here to examine...");

                }
                else
                {
                    Console.WriteLine($"This is the {targetDoor.name}.");
                    Console.WriteLine(targetDoor.description);
                }   
            }
            else
            {
                Console.WriteLine($"There is no {playerInput} here...");
            }
           
        }
        void PickUp(string _target)
        {
            playerInput = "";
            Item targetItem = null;
            
            playerInput = playerInputController.PickUpActionPrompt(_target);


            Console.Clear();
            targetItem = CheckItemsInCurrentLocation(playerInput);
            
            if (targetItem != null)
            {
                if (targetItem.canPickUp)
                {
                    targetItem.location = AllRoomObjects.GiveRoom(" ");
                    inventory.Add(targetItem);
                    noteBook.playersInventory.Add(targetItem);
                    Console.Write($"You picked up a/an ");
                    ObjectColors.ItemColor(targetItem.name);
                    Console.WriteLine();
                }
                else
                {
                    Console.Write($"You cannot pick up the ");
                    ObjectColors.ItemColor(targetItem.name);
                    Console.WriteLine();
                }
                    
            }
            else
            {
                Console.WriteLine($"There is no item here called: {playerInput}");
            }



        }
        void Talk(string _target)
        {
            Character targetCharacter;

            playerInput = playerInputController.TalkActionPrompt(_target);


            targetCharacter = CheckCharactersInCurrentLocation(playerInput);

            if (targetCharacter != null)
            {
                AskQuestions(targetCharacter);
            }
            else
            {
                Console.WriteLine($"There is no {playerInput} here...");
            }

        }
        void OpenPlayersNoteBook()
        {
            playerInputController.OpenNoteBookPrompt();
        }
        void CheckInventory()
        {
            Console.Clear();
            if (inventory.Count == 0)
            {
                Console.WriteLine("You don't have any items.");
            }
            foreach (Item item in inventory)
            {
                ObjectColors.ItemColor(item.name);
                Console.WriteLine();
            }
        }
        void AskQuestions(Character _targetCharacter)
        {
            Console.Clear();
            playerInputController.AskQuestionsActionPrompt(_targetCharacter);
            
        }
        void Interact(string _target)
        {
            playerInput = "";
            Item targetItem;
            Character targetCharacter;
            Door targetDoor;
            
            playerInput = playerInputController.InteractActionPrompt(_target);

            Console.Clear();
            targetItem = CheckItemsInCurrentLocation(playerInput);
            targetCharacter = CheckCharactersInCurrentLocation(playerInput);
            targetDoor = CheckDoorsInCurrentLocation(playerInput);


            if (playerInput == PoliceVan.name.ToLower())
            {
                if (this.currentLocation.roomID != PoliceVan.location.roomID)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.Write("The  ");
                    ObjectColors.PoliceVanName();
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine(" is not here.");
                    Console.ResetColor();
                }
                else
                {
                    //Console.WriteLine($"Interacting with the VAN");
                    //Interact with van in playerInputController.
                    playerInputController.InteractingWithVan();
                }
            }
            else if (targetItem != null)
            {
                Console.WriteLine(targetItem.interactDescription);
                if (targetItem.isContainer)
                {
                    inventory = playerInputController.InteractingWithItemContainer(targetItem, inventory);
                }    
            }
            else if (targetCharacter != null)
            {
                Console.Write($"To interact with ");
                ObjectColors.PersonColor(targetCharacter.name);
                Console.WriteLine(", use \'Talk\'.");
            }
            else if (targetDoor !=null)
            {
                Console.Clear();
                if (targetDoor.doorID == " ") Console.WriteLine("There is no door here to interact with...");
                else if (targetDoor.isDoor) playerInputController.InteractingWithDoor(targetDoor,inventory);
                else Console.WriteLine($"Cannot interact with the {targetDoor.name}");
            }
            else
            {
                Console.WriteLine($"There is no {playerInput} here...");
            }
        }


        
        Item CheckItemsInCurrentLocation(string _playerInput)
        {
            foreach (Item item in AllItemObjects.items)
            {
                string targetName = item.name.ToLower();
                if (_playerInput == targetName && item.location == this.currentLocation)
                {
                    return item;
                }
                else if (_playerInput == targetName && inventory.Contains(item))
                {
                    return item;
                }
            }
            return null;
        }
        Character CheckCharactersInCurrentLocation(string _playerInput)
        {
            foreach (Character character in AllCharacterObjects.allCharacters)
            {
                string targetName = character.name.ToLower();
                if (_playerInput == targetName && character.location == this.currentLocation)
                {
                    return character;
                }
            }
            return null;
        }
        Door CheckDoorsInCurrentLocation(string _playerInput)
        {
            Door[] currentLocationDoors = { currentLocation.northDoor, currentLocation.southDoor, currentLocation.eastDoor, currentLocation.westDoor };
            foreach (Door door in currentLocationDoors)
            {
                string targetName = door.name.ToLower();
                if (_playerInput == targetName)
                {
                    return door;
                }
            }
            return null;
        }
    }
}
