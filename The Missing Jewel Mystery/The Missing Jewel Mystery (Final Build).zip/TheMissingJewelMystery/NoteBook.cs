﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheMissingJewelMystery_Prototype1
{
    class NoteBook
    {
        public List<Clue> loggedClues = new List<Clue>();     //Keeps track of player clue's that have been obtained.
        public List<Clue> statementClues = new List<Clue>();   //Keeps track of all clues observed via items
        public List<Clue> observationClues = new List<Clue>(); //Keeps track of all clues from statements via questions
        
        public List<Item> playersInventory = new List<Item>();

        const string OBSERVATION = "Observation";
        const string STATEMENT = "Statement";


        public void RevealClues(List<Clue> targetList)
        {
            int number = 1;
            foreach (Clue clue in targetList)
            {
                if (clue.clueType == STATEMENT) Console.WriteLine($" {number}) {clue.personStatementBy}  :  {clue.clueSummary}");
                else Console.WriteLine($" {number}) {clue.clueName}  :  {clue.clueSummary}");
                number++;
            }
        }

        public void AddClue(Clue targetClue)
        {
            bool clueLogged = false;
            if (targetClue.clueType == OBSERVATION)
            {
                foreach (Clue clue in observationClues)
                {
                    if (clue.clueID == targetClue.clueID) clueLogged = true;
                }
                if (!clueLogged)
                {
                    loggedClues.Add(targetClue);
                    observationClues.Add(targetClue);
                    OrganizeObservationClues();
                }
                
            }
            else
            {
                foreach (Clue clue in statementClues)
                {
                    if (clue.clueSummary == targetClue.clueSummary) clueLogged = true;
                }
                if (!clueLogged)
                {
                    loggedClues.Add(targetClue);
                    statementClues.Add(targetClue);
                    OrganizeStatements();
                }
            }
        }
        public void RemoveClue(int targetClueNumber, List<Clue> targetList)
        {
            Clue targetClue = targetList[targetClueNumber];
            foreach (Clue clue in loggedClues)
            {
                if (clue.clueID == targetClue.clueID) 
                {
                    loggedClues.Remove(clue);
                    break;
                }
            }
            targetList.RemoveAt(targetClueNumber);
        }

        public void OrganizeStatements()
        {
            if (statementClues.Count > 1)
            {
                for (int i = 0; i < statementClues.Count-1; i++)
                {
                    bool allSameLetters = true;
                    Clue clue = statementClues[i];
                    Clue nextClue = statementClues[i+1];

                    string cluePerson = clue.personStatementBy;
                    string nextCluePerson = nextClue.personStatementBy;
                    
                    int shortestLength;
                    if (cluePerson.Length <= nextCluePerson.Length) shortestLength = cluePerson.Length;
                    else shortestLength = nextCluePerson.Length;

                    for (int c = 0; c < shortestLength; c++)
                    {
                        //a is smaller
                        //b is bigger
                        // so a < b
                        // If a > b, switch

                        if (cluePerson[c] > nextCluePerson[c])
                        {
                            Clue temp = clue;
                            statementClues[i] = nextClue;
                            statementClues[i + 1] = temp;
                            i = -1;
                            allSameLetters = false;
                            break;
                        }
                        else if (cluePerson[c] < nextCluePerson[c])
                        {
                            allSameLetters = false;
                            break;
                        }
                    }
                    if (allSameLetters)
                    {
                        if (cluePerson.Length > nextCluePerson.Length)
                        {
                            Clue temp = clue;
                            statementClues[i] = nextClue;
                            statementClues[i + 1] = temp;
                            i = -1;
                        }
                    }


                }
                //Out of loop


            }
        }

        public void OrganizeObservationClues()
        {
            if (observationClues.Count > 1)
            {
                for (int i = 0; i < observationClues.Count - 1; i++)
                {
                    bool allSameLetters = true;
                    Clue clue = observationClues[i];
                    Clue nextClue = observationClues[i + 1];

                    string clueName = clue.clueName;
                    string nextClueName = nextClue.clueName;

                    int shortestLength;
                    if (clueName.Length <= nextClueName.Length) shortestLength = clueName.Length;
                    else shortestLength = nextClueName.Length;

                    for (int c = 0; c < shortestLength; c++)
                    {
                        //a is smaller
                        //b is bigger
                        // so a < b
                        // If a > b, switch

                        if (clueName[c] > nextClueName[c])
                        {
                            Clue temp = clue;
                            observationClues[i] = nextClue;
                            observationClues[i + 1] = temp;
                            i = -1;
                            allSameLetters = false;
                            break;
                        }
                        else if (clueName[c] < nextClueName[c])
                        {
                            allSameLetters = false;
                            break;
                        }
                    }
                    if (allSameLetters)
                    {
                        if (clueName.Length > nextClueName.Length)
                        {
                            Clue temp = clue;
                            observationClues[i] = nextClue;
                            observationClues[i + 1] = temp;
                            i = -1;
                        }
                    }


                }
                //Out of loop
            }
        }


    }
}
