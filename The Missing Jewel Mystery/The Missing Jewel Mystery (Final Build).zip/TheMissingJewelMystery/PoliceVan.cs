﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TheMissingJewelMystery_Prototype1;

namespace TheMissingJewelMystery
{
    static class PoliceVan
    {
        public static string name = "Police Van";
        public static string currentState = "Sitting at the roundabout.";
        public static string description = "A standard van. There is room inside to hold a small array for suspects, along with evidence.";
        public static Room location = AllRoomObjects.GiveRoom("RoundAboutRoomID");


        static public List<string> suspects = new List<string>();
        static public List<Item> containedItems = new List<Item>();


        
        
        static public void DisplayAllSuspects()
        {
            int number = 1;

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(" SUSPECTS: ");

            foreach(string suspect in suspects)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write($" {number}. ");
                ObjectColors.PersonColor(suspect);
                Console.ResetColor();
                Console.WriteLine();
                number++;
            }

        }
        static public void AddSuspect(Character targetCharacter)
        {
            suspects.Add(targetCharacter.name);
        }
        static public void RemoveSuspect(string targetName)
        {
            suspects.Remove(targetName);
        }

        static public void DisplayAllHeldItems()
        {
            int number = 1;

            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(" ITEMS: ");

            foreach (Item item in containedItems)
            {
                Console.ForegroundColor = ConsoleColor.Red;
                Console.Write($" {number}. ");
                ObjectColors.ItemColor(item.name);
                Console.ResetColor();
                Console.WriteLine();
                number++;
            }
        }
        static public void AddItem(Item targetItem)
        {
            containedItems.Add(targetItem);
        }

        static public void RemoveItem(int number)
        {
            containedItems.RemoveAt(number);
        }


    }
}
