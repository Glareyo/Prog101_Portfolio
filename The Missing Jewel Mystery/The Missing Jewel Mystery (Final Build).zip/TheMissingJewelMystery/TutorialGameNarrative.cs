﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices.ComTypes;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;
using TheMissingJewelMystery;

namespace TheMissingJewelMystery_Prototype1
{
    class TutorialGameNarrative
    {
        Room startingLocation = AllRoomObjects.GiveRoom("DetectiveOfficeSouthRoomID");
        Player player;
        string Michelle = "Michelle";
        Item newspaper = AllItemObjects.GiveItem("DetectiveNewspaperItemID");
        



        public TutorialGameNarrative(Player _player)
        {
            player = _player;
            player.currentLocation = startingLocation;
        }


        public void BeginNarrative()
        {
            MediaController.tutorialMusic.PlayLooping();   
            player.inventory.Clear();
            Console.Clear();
            StartingNarrative();
        }
        void StartingNarrative()
        {
            Narrate("A loud knock disturbs you from your sleep");
            Continue();
            Narrate("Everything seems fuzzy...");
            Narrate("You're not sure where you are...but it feels like you were sleeping on a hard surface.");

            Narrate("The knocking continues, this time a little more persistent and rigid...");
            Narrate("With you best \"Morning\" voice, you answer: ");
            Continue();

            Dialog(player.name, "Who is it?");

            Continue();

            Dialog(Michelle, "It’s Michelle! Would you open the door? I got a case for you that might be of interest!");

            Continue();

            Console.Clear();

            Narrate("Your eyes begin to clear up a bit.");
            Narrate("It seems you were sleeping at your desk...");

            Narrate("Slowly, you rise out of your chair...");

            Continue();

            Console.Clear();
            while (true)
            {
                if (player.currentLocation != startingLocation)
                {
                    Console.Clear();
                    Narrate("You cannot go that way yet. \n");
                    player.currentLocation = startingLocation;

                }
                Narrate("Let’s get your bearings together.");
                Narrate("Press X to examine AND input \"Room\"");

                player.PlayerAction();
                if (player.targetInputAction == "x")
                {
                    if (player.playerInput == "room") break;
                }
            }

            Continue();
            Narrate("Michelle knocks again...");
            Dialog(Michelle, "Can you hear me in there?");

            Continue();

            while (true)
            {
                if (player.currentLocation != startingLocation)
                {
                    Console.Clear();
                    Narrate("You cannot go that way yet. \n");
                    player.currentLocation = startingLocation;

                }
                
                Dialog(player.name, "My head feels a bit wonky. What exactly did I drink?");
                Narrate("There seems to be an EMPTY BOTTLE in the room.");
                Narrate("Press X to examine, and input \"Empty Bottle\"");

                player.PlayerAction();
                if (player.targetInputAction == "x")
                {
                    if (player.playerInput == AllItemObjects.GiveItem("EmptyLiquorBottleItemID").name.ToLower()) break;
                }
            }

            Dialog(player.name, "It would probably be best to remove it from the desk...");
            Continue();

            Console.Clear();

            //Player picks up the bottle
            while (true)
            {
                if (player.currentLocation != startingLocation)
                {
                    Console.Clear();
                    Narrate("You cannot go that way yet. \n");
                    player.currentLocation = startingLocation;
                }
                bool playerHasItem = false;
                foreach (Item item in player.inventory)
                    if (item.itemID == "EmptyLiquorBottleItemID") playerHasItem = true;
                if (playerHasItem) break;

                Narrate("Press P to pickup, and input \"Empty Bottle\"");

                player.PlayerAction();
            }
            Continue();
            Console.Clear();

            //Player examines the newspaper.
            while (true)
            {
                bool playerHasItem = false;
                
                if (player.currentLocation != startingLocation)
                {
                    Console.Clear();
                    Narrate("You cannot go that way yet. \n");
                    player.currentLocation = startingLocation;
                }

                foreach (Item item in player.inventory)
                {
                    if (item.itemID == newspaper.itemID) playerHasItem = true;
                }
                if (playerHasItem) Dialog(player.name,"I have a newspaper. Maybe I should read it...");
                else Dialog(player.name,"There's a newspaper on my desk. Maybe I should read it.");
                
                

                Narrate($"Press X to examine, and input \"{newspaper.name.ToUpper()}\"");

                

                player.PlayerAction();
                if (player.targetInputAction == "x")
                {
                    if (player.playerInput == newspaper.name.ToLower()) break;
                    Console.Clear();
                }
            }



            //Player marks with the newspaper.
            while (true)
            {
                bool playerMarkedClue = false;


                

                if (player.currentLocation != startingLocation)
                {
                    Console.Clear();
                    Narrate("You cannot go that way yet. \n");
                    player.currentLocation = startingLocation;
                }

                foreach (Clue clue in player.noteBook.loggedClues)
                {
                    if (clue.clueID == newspaper.clue.clueID) break;
                }

                Dialog(player.name, "That may be important later on. I should mark it in my notebook.");


                Narrate($"Press M to mark, and input \"{newspaper.name.ToUpper()}\"");

                

                player.PlayerAction();
                if (player.targetInputAction == "m")
                {
                    if (player.playerInput == newspaper.name.ToLower()) break;
                }
            }



            Continue();
            Console.Clear();

            while (true)
            {
                if (player.currentLocation != startingLocation)
                {
                    Console.Clear();
                    Narrate("You cannot go that way yet. \n");
                    player.currentLocation = startingLocation;
                }


                Dialog(player.name, "There, I now have the newspaper as a clue in my notebook.");
                Narrate("Let's check your notebook.");
                Narrate("Press O to open your notebook");

                player.PlayerAction();
                if (player.targetInputAction == "o")
                {
                    break;
                }
            }

            Narrate("As you noticed, all clues that you mark will be logged into your notebook.");
            Narrate("Items marked as clues will be found under \"Observations\"");
            Narrate("Questions and statements from people marked as clues will be found under \"Statements\"");

            Continue();

            Narrate("At your own choice, clues can also be removed from the notebook via the notebook menu.");

            Continue();


            //Player checks inventory
            while (true)
            {
                if (player.currentLocation != startingLocation)
                {
                    Console.Clear();
                    Narrate("You cannot go that way yet. \n");
                    player.currentLocation = startingLocation;
                }
                Dialog(player.name, "I need the keys to my door. Maybe I might have it in my possessions?");
                Narrate("Let's check your inventory.");
                Narrate("Press C to Check your inventory");

                player.PlayerAction();
                if (player.targetInputAction == "c")
                {
                    break;
                }
            }

            Continue();

            Dialog(player.name, "Doesn't seem like I do...");
            Dialog(player.name, "Now where did I put my keys?");

            //Re-examine
            while (true)
            {
                
                Dialog(player.name, "It could be possible that they’re in my coat further ahead in the room...");
                Narrate("Let's begin moving around in the room.");
                Narrate("Re-examine the room to know where to go...");

                player.PlayerAction();
                if (player.targetInputAction == "x")
                {
                    if (player.playerInput == "room") break;
                }
                else if (player.currentLocation != startingLocation) break;
                else
                {
                    Narrate("To examine the room, press X and input \"room\"");
                }
            }


            //Player goes north
            while (true)
            {
                if (player.currentLocation != startingLocation) break;
                Narrate("Press N to Go North");
                player.PlayerAction();
                
            }


            //Player takes key from coat
            while (true)
            {
                bool playerHasKey = false;
                foreach (Item item in player.inventory)
                {
                    if (item.itemID == "DetectiveDrawerKeyItemID") playerHasKey = true;
                }

                if (playerHasKey) break;

                Dialog(player.name, "Here's my coat");
                Narrate("Press I to interact, and input the \"Coat\" to open the Interact Menu");
                Narrate("Press \"1\" to open the coat in the Interact Menu");
                Narrate("Press \"0\" to exit the Interact Menu");

                player.PlayerAction();
                if (player.targetInputAction == "i")
                {
                    if (player.playerInput == AllItemObjects.GiveItem("DetectiveCoatItemID").name.ToLower())
                    {
                        break;
                    }
                }
            }

            Dialog(player.name, "It looks like my keys aren't in here...");
            Dialog(player.name, "But my drawer keys are...");
            Continue();

            Console.Clear();

            //Player takes key out of the coat
            while (true)
            {
                bool playerHasKey = false;
                foreach (Item item in player.inventory)
                {
                    if (item.itemID == "DetectiveDrawerKeyItemID") playerHasKey = true;
                }

                if (playerHasKey) break;


                Dialog(player.name, "I should take the keys out.");
                Narrate("Interact with the coat again...");
                Narrate("Press \"3\" in the Interact Menu, and input the corresponding number of the key.");
                Narrate("Once done, press \"0\" until you are out of the Interact Menu");

                player.PlayerAction();
            }

            Dialog(player.name, "Well...I won't be able to open my entry door without my keys...");

            Dialog(player.name, "My door keys might be in my bedroom...");
            Continue();


            //Player goes east
            while (true)
            {
                Narrate("Press E to go East");
                player.PlayerAction();
                if (player.targetInputAction == "e") break;
            }

            while (true)
            {
                if (AllDoorObjects.GiveDoor("DetectiveBedroomDoorID").isOpen == true) break;

                Dialog(player.name, "It would probably be best to open the door first...");
                Narrate("Interact with the door via name, the name of the door being \"Bedroom Door\".");
                Narrate("In the Interact Menu, OPEN the Door via the corresponding option number, (1).");
                Narrate("Press 0 to exit.");

                player.PlayerAction();

            }

            while (true)
            {
                if (player.currentLocation == AllRoomObjects.GiveRoom("DetectiveBedroomRoomID")) break;
                Dialog(player.name, "Now I can go east...");
                Narrate("Press E to go East");
                player.PlayerAction();
            }

            while (true)
            {
                Narrate("Interact with the drawer.");
                player.PlayerAction();
                if (player.targetInputAction == "i") break;
            }

            //Player unlocks the drawer
            while (true)
            {
                if (AllItemObjects.GiveItem("DetectiveBedroomDrawerItemID").isLocked == false) break;
                Dialog(player.name, "The drawer is locked, but I do have the key for it...");
                Narrate("Re-interact with the drawer.");
                Narrate("In the Interact Menu, input the corresponding number to UNLOCK the drawer");
                Narrate("Select the KEY via corresponding number in the Interacting --> Unlock Menu, to unlock.");
                Narrate("Press 0 to exit the Interact Menu");
                player.PlayerAction();
            }


            //Player takes out entry key
            while (true)
            {
                bool playerHasKey = false;
                foreach (Item item in player.inventory)
                {
                    if (item.itemID == "DetectiveOfficeKeyItemID") playerHasKey = true;
                }
                if (playerHasKey) break;
                Dialog(player.name, "Now I can take the entry key.");
                Narrate("Interact with the drawer and take out the entry key.");
                player.PlayerAction();
            }

            Dialog(player.name, "Time to answer the door...");
            Continue();

            while (true)
            {
                if (player.currentLocation == AllRoomObjects.GiveRoom("DetectiveOfficeCenterRoomID")) break;
                Narrate("Navigate back to the " + AllRoomObjects.GiveRoom("DetectiveOfficeCenterRoomID").name);
                Narrate("Press W to go west.");
                player.PlayerAction();
            }
            Console.Clear();

            if (AllDoorObjects.GiveDoor("DetectiveEntryDoorID").isOpen == false) Narrate("There's another knock on the door...");


            while (true)
            {
                if (AllDoorObjects.GiveDoor("DetectiveEntryDoorID").isOpen == true) break;
                Narrate("Interact, unlock, and open the entry door.");
                Narrate("To use shortcut commands. Rather than typing in the full name for doors, you can use:");
                Narrate(" - \"n\", or \"north\" for a door to the north.");
                Narrate(" - \"s\", or \"south\" for a door to the south.");
                Narrate(" - \"e\", or \"east\" for a door to the east.");
                Narrate(" - \"w\", or \"west\" for a door to the west.");
                player.PlayerAction();
            }

            Continue();


            while(true)
            {
                if (player.currentLocation == AllRoomObjects.GiveRoom("DetectiveOfficeOutsideRoomID")) break;
                Narrate("Navigate to the " + AllRoomObjects.GiveRoom("DetectiveOfficeOutsideRoomID").name);
                player.PlayerAction();
            }

            while(true)
            {
                Narrate("Press T to talk, and input \"officer michelle\" to talk to Michelle");
                Narrate("Press the corresponding # keys to select the prompts");

                player.PlayerAction();
                if (player.targetInputAction == "t")
                {
                    if (player.playerInput == "officer michelle") break;
                }
            }

            Narrate("As you noticed, some questions require other questions to be answered.");
            Narrate("Questions have not been asked / answered yet are highlighted in red...");

            Continue();
            Console.Clear();

            Narrate("In addition, having marked clues can unlock additional questions for certain characters.");
            Narrate("To mark a question as a clue, you must first ask the question...");
            Narrate("...then input M as your next input while in the Talking Menu");

            Continue();
            Console.Clear();

            Dialog(player.name, "Give me another minute. Let me go grab my HAT, my COAT, and my GUN.");

            Continue();

            while(true)
            {
                bool playerHasCoat = false;
                bool playerHasGun = false;
                bool playerHasHat = false;
                foreach (Item item in player.inventory)
                {
                    if (item.itemID == "DetectiveGunItemID") playerHasGun = true;
                    if (item.itemID == "DetectiveCoatItemID") playerHasCoat = true;
                    if (item.itemID == "DetectiveHatItemID") playerHasHat = true;
                }
                if (playerHasCoat && playerHasGun && playerHasHat) break;

                Narrate("Navigate your office and pickup your HAT, COAT, and GUN");
                Narrate("Use the Map Interface for references of the controls.");
                Narrate("Use the Map Compass to know where rooms are.");
                player.PlayerAction();
            }


            foreach(Room room in AllRoomObjects.rooms)
            {
                if (room.roomID == "DetectiveOfficeOutsideRoomID")
                {
                    room.westDoor.isOpen = true;
                }
            }

            
            while(true)
            {
                if (player.currentLocation == AllRoomObjects.GiveRoom("DetectiveExitTutorialRoomID")) break;
                Narrate("To complete the tutorial, make your way back to the " + AllRoomObjects.GiveRoom("DetectiveOfficeOutsideRoomID").name + " and go west.");
                player.PlayerAction();
            }
            Console.Clear();

            Narrate("Tutorial Complete.");
            Narrate("You will be returned to the main menu");
            Continue();
            MediaController.tutorialMusic.Stop();
        }




        void Continue()
        {
            Console.WriteLine();
            Console.WriteLine(CenterString("Press \"Enter\" to Continue"));
            Console.ReadLine();
        }


        string CenterString(string _string)
        {
            string centeredString = "";

            for (int i = 0; i < (Console.WindowWidth / 2) - (_string.Length / 2); i++)
            {
                centeredString += " ";
            }
            centeredString += _string;
            return centeredString;
        }
        void Narrate(string _phrase)
        {
            Console.Write("\n ");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(CenterString(_phrase));
            Console.ResetColor();
        }
        void Dialog(string _name, string _phrase)
        {
            string fullString = _name + " : " + _phrase;

            //Use the center string code
            for (int i = 0; i < (Console.WindowWidth / 2) - (fullString.Length / 2); i++)
            {
                Console.Write(" ");
            }


            ObjectColors.PersonColor(_name);
            Console.Write(" : ");

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"\"{_phrase}\"");
            Console.ResetColor();
        }
    }
}
