﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheMissingJewelMystery_Prototype1
{
    class AllCharacterObjects
    {
        string targetFolder = "AllCharactersFolder";
        string directoryPath;
        string[] InfoFiles;

        static public List<Character> allCharacters = new List<Character>();
        
        
        void SetDirectory()
        {
            directoryPath = Directory.GetCurrentDirectory();
            directoryPath = Path.Combine(directoryPath, targetFolder);
            InfoFiles = Directory.GetFiles(directoryPath);
        }


        public void CreateCharacters()
        {
            SetDirectory();

            int numberOfCharacters = InfoFiles.Length;
            Character[] charactersArray = new Character[numberOfCharacters];
            int characterNum = 0;

            

            foreach (string file in InfoFiles)
            {
                string[] textLineInfo = File.ReadAllLines(file);
                string nameInfo = "";
                string currentStateInfo = "";
                string descriptionInfo = "";
                string locationInfo = "";

                Room location = null;
                List<Question> questionList = new List<Question>();

                string[] requiredInfo = { nameInfo, currentStateInfo, descriptionInfo, locationInfo };
                int number = 0;
                
                for (int i = 0; i < textLineInfo.Length; i++)
                {
                    if (textLineInfo[i][0] != '-')
                    {
                        requiredInfo[number] = textLineInfo[i];
                        number++;
                    }
                }
                nameInfo = requiredInfo[0];
                currentStateInfo = requiredInfo[1];
                descriptionInfo = requiredInfo[2];
                locationInfo = requiredInfo[3];

                //Get the target room via ID.
                location = AllRoomObjects.GiveRoom(locationInfo);
                questionList = CreateQuestions(directoryPath, nameInfo,characterNum);



                //Assign Required questions to each question that has a corresponding question ID
                foreach (Question currentQuestion in questionList)
                {
                    if (currentQuestion.requiredQuestionID[0] != ' ')
                    {
                        foreach (Question targetQuestion in questionList)
                        {
                            if (currentQuestion.requiredQuestionID == targetQuestion.questionID)
                            {
                                currentQuestion.requiredQuestion = targetQuestion;
                            }
                        }
                    }
                }



                //Create character
                charactersArray[characterNum] = new Character(nameInfo, currentStateInfo, descriptionInfo, location, questionList);
                foreach(Question question in charactersArray[characterNum].questionList)
                {
                    question.clue = new Clue(charactersArray[characterNum], question);
                }


                allCharacters.Add(charactersArray[characterNum]);
                characterNum++;
            }
            //Ending of Loop



        }

        List<Question> CreateQuestions(string characterDirectory, string characterName, int characterNum)
        {
            
            string questionDirectoryName;
            string[] questionFiles;
            
            
            List<Question> tempList = new List<Question>();
            int questionNum = 0;

            //Set Directory to associated Character's questions
            questionDirectoryName = characterName + "QuestionFolder";
            questionDirectoryName = Path.Combine(characterDirectory, questionDirectoryName);
            questionFiles = Directory.GetFiles(questionDirectoryName);

            int numberOfQuestions = questionFiles.Length;
            Question[] questionsArray = new Question[numberOfQuestions];

            foreach (string file in questionFiles)
            {
                string[] lineInfo = File.ReadAllLines(file);
                string questionIDInfo = "0";
                string questionPromptInfo = "1";
                string answerPromptInfo = "2";
                string requiredQuestionIDInfo = "3";
                string requiredClueIDInfo = "4";
                string clueSummaryInfo = "5";

                string[] requiredQInfo = { questionIDInfo, questionPromptInfo, answerPromptInfo, requiredQuestionIDInfo, requiredClueIDInfo, clueSummaryInfo };
                int arrayElementNum = 0;


                for(int i = 0; i < lineInfo.Length; i++)
                {
                    if (lineInfo[i][0] != '-')
                    {
                        requiredQInfo[arrayElementNum] = lineInfo[i];
                        arrayElementNum++;
                    }
                }
                string questionID = requiredQInfo[0];
                string questionPrompt = requiredQInfo[1];
                string answerPrompt = requiredQInfo[2];
                string requiredQuestionID = requiredQInfo[3];
                string requiredClueID = requiredQInfo[4];
                string clueSummary = requiredQInfo[5];


                questionsArray[questionNum] = new Question(questionID, questionPrompt,answerPrompt,requiredQuestionID,requiredClueID,clueSummary, characterName);
                tempList.Add(questionsArray[questionNum]);
                questionNum++;
            }

            return tempList;



        }






       

    }
}
