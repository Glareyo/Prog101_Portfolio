﻿using Microsoft.SqlServer.Server;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheMissingJewelMystery_Prototype1
{
    class MainMenu
    {
        //narrative1
        //narrative2

        Player player;
        string title = "The Missing Jewel Mystery.";
        int currentChoice = 0;

        string[] MenuPrompts =
        {
            "Main Game",
            "Tutorial",
            "Credits",
            "Exit"
        };
        public MainMenu(Player _player)
        {
            player = _player;
        }

        
        public void MenuStartup()
        {
            Menu();
        }
        void Menu()
        {
            while(true)
            {
                Console.Clear();
                
                Console.WriteLine(CenterString(title));
                for (int i = 0; i < Console.WindowWidth; i++) Console.Write("-");
                Console.WriteLine();

                //Introduce Player
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(CenterString("Hello, Detective:"));

                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.WriteLine(CenterString(player.name));
                Console.WriteLine();
                Console.ResetColor();

                //Prompt Inputs
                Console.ForegroundColor = ConsoleColor.Green;
                Console.WriteLine(CenterString("Use the UP and DOWN arrow keys to navigate the menu."));
                Console.WriteLine(CenterString("Press \"Enter\" to select."));
                Console.WriteLine("\n");
                Console.ResetColor();

                for (int i = 0; i < MenuPrompts.Length; i++)
                {
                    
                    
                    if (currentChoice == i)
                    {
                        foreach (char c in CenterString(MenuPrompts[i]))
                        {
                            if (c != ' ')
                            {
                                Console.BackgroundColor = ConsoleColor.White;
                                Console.ForegroundColor = ConsoleColor.Black;
                            }
                            Console.Write(c);
                        }
                    }
                    else Console.Write(CenterString(MenuPrompts[i]));
                    Console.WriteLine();
                    Console.ResetColor();
                }


                // Using https://learn.microsoft.com/en-us/dotnet/api/system.consolekeyinfo.key?view=net-6.0 as a reference for learning keys.

                string keyPressed = Console.ReadKey().Key.ToString();

                string enterKeyString = ConsoleKey.Enter.ToString();
                string upArrowString = ConsoleKey.UpArrow.ToString();
                string downArrowString = ConsoleKey.DownArrow.ToString();

                
                if (keyPressed == upArrowString)
                {
                    currentChoice--;
                    if (currentChoice < 0) currentChoice = MenuPrompts.Length-1;
                }
                else if (keyPressed == downArrowString)
                {
                    currentChoice++;
                    if (currentChoice > MenuPrompts.Length-1) currentChoice = 0;
                }
                else if (keyPressed == enterKeyString)
                {
                    break;
                }
            }
        }
        
        public int GetSelectedMenuChoice()
        {
            return currentChoice;
        }
        string CenterString(string _string)
        {
            string centeredString = "";

            for (int i = 0; i < (Console.WindowWidth / 2) - (_string.Length / 2); i++)
            {
                centeredString += " ";
            }
            centeredString += _string;
            return centeredString;
        }

    }
}
