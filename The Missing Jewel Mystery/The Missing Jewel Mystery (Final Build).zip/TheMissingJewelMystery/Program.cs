﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;

namespace TheMissingJewelMystery_Prototype1
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Game game = new Game();
            game.GameStartUp();
        }
    }
}
