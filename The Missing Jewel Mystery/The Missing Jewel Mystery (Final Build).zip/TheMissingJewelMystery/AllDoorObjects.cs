﻿using System;
using System.Collections.Generic;
using System.Data.Common;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheMissingJewelMystery_Prototype1
{
    class AllDoorObjects
    {
        string targetFolder = "AllDoorsFolder";
        string directoryPath;
        string[] InfoFiles;
        

        static public List<Door> doors = new List<Door>();






        void SetDirectory()
        {
            directoryPath = Directory.GetCurrentDirectory();
            directoryPath = Path.Combine(directoryPath, targetFolder);
            InfoFiles = Directory.GetFiles(directoryPath);
        }
        public void CreateDoors()
        {
            SetDirectory();

            int numberOfDoors = InfoFiles.Length;
            Door[] AllDoorsArray = new Door[numberOfDoors];
            int doorNumber = 0;

            
            string doorIDInfo = "0";
            string nameInfo = "1";
            string descriptionInfo = "2";
            string openingDescriptionInfo = "3";
            string closingDescriptionInfo = "4";
            string unlockingDescriptionInfo = "5";
            string lockingDescriptionInfo = "6";
            string isDoorInfo = "7";
            string lockableInfo = "8";
            string openableInfo = "9";
            string isLockedInfo = "10";
            string isOpenInfo = "11";
            string isClearInfo = "12";
            string keyInfo = "13";

            string[] requiredInfo = {doorIDInfo, nameInfo, descriptionInfo, openingDescriptionInfo, closingDescriptionInfo, unlockingDescriptionInfo, lockingDescriptionInfo, isDoorInfo, lockableInfo, openableInfo, isLockedInfo, isOpenInfo, isClearInfo, keyInfo};

            string doorID;
            string name;
            string description;
            string openingDescription;
            string closingDescription;
            string unlockingDescription;
            string lockingDescription;
            bool isDoor;
            bool lockable;
            bool openable;
            bool isLocked;
            bool isOpen;
            bool isClear;
            
            foreach (string file in InfoFiles)
            {
                int number = 0;
                string[] textLineInfo = File.ReadAllLines(file);


                for (int i = 0; i < textLineInfo.Length; i++)
                {
                    try
                    {
                        if (textLineInfo[i][0] != '-')
                        {
                            requiredInfo[number] = textLineInfo[i];
                            number++;
                        }
                    }
                    catch
                    {
                        Console.WriteLine($"ERROR AT {file}");
                    }
                    
                }
                //Set object strings
                doorID = requiredInfo[0];
                name = requiredInfo[1];
                description = requiredInfo[2];
                openingDescription = requiredInfo[3];
                closingDescription = requiredInfo[4];
                unlockingDescription = requiredInfo[5];
                lockingDescription = requiredInfo[6];

                //Set bool strings
                isDoorInfo = requiredInfo[7];
                lockableInfo = requiredInfo[8];
                openableInfo = requiredInfo[9];
                isLockedInfo = requiredInfo[10];
                isOpenInfo = requiredInfo[11];
                isClearInfo = requiredInfo[12];

                keyInfo = requiredInfo[13];

                //Set Bools
                isDoor = Convert.ToBoolean(isDoorInfo);
                lockable = Convert.ToBoolean(lockableInfo);
                openable = Convert.ToBoolean(openableInfo);
                isLocked = Convert.ToBoolean(isLockedInfo);
                isOpen = Convert.ToBoolean(isOpenInfo);
                isClear = Convert.ToBoolean(isClearInfo);

                
                
                

                //Create door and add to list
                AllDoorsArray[doorNumber] = new Door(doorID, name, description, openingDescription,closingDescription,unlockingDescription, lockingDescription, isDoor, lockable, openable, isLocked, isOpen, isClear, keyInfo);
                doors.Add(AllDoorsArray[doorNumber]);

                

                doorNumber++;
            }


        }

        static public Door GiveDoor(string _doorID)
        {
            foreach (Door door in doors)
            {
                if (_doorID == door.doorID)
                {
                    return door;
                }
            }
            return null;
        }
        




        

    }
}
