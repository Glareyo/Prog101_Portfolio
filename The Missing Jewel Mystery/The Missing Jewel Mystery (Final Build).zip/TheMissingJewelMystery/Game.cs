﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Media;
using System.Timers;
using System.Security.Principal;
using TheMissingJewelMystery;
using System.Diagnostics;

namespace TheMissingJewelMystery_Prototype1
{
    class Game
    {
        

        
        
        public Player player;
        
        public AllRoomObjects allRoomObjects = new AllRoomObjects();
        public AllCharacterObjects allCharacterObjects = new AllCharacterObjects();
        public AllItemObjects allItemObjects = new AllItemObjects();
        public AllDoorObjects allDoorObjects = new AllDoorObjects();

        public MainMenu mainMenu;
        public TutorialGameNarrative tutorial;
        public MainGameNarrative mainGame;



        public void GameStartUp()
        {
            string playerName;


            SetGame();


            Console.WindowWidth = Console.LargestWindowWidth - 20;
            Console.WindowHeight = Console.LargestWindowHeight-10;
            Console.WindowTop = 0;
            Console.WindowLeft = 0;
            Console.Title = "The Missing Jewel Mystery";

            Console.WriteLine(CenterString("Hello"));
            Console.Write(CenterString("Please enter you name: "));

            playerName = Console.ReadLine();
            player = new Player(playerName);

            Console.WriteLine();
            Console.WriteLine(CenterString("This game utilizes music, though this doesn't directly affect gameplay..."));
            Console.WriteLine(CenterString("If you wish to have the music off, please lower the volume."));
            Console.WriteLine(CenterString("Press enter to continue..."));
            Console.ReadLine();

            mainMenu = new MainMenu(player);
            tutorial = new TutorialGameNarrative(player);
            mainGame = new MainGameNarrative(player);

            Console.Clear();

            try
            {
                MediaController.mainMenuMusic.PlayLooping();
            }
            catch
            {
                Console.WriteLine("Error, attempting to play music. Music has failed to load.");
                Console.ReadLine();
            }
            while (true)
            {

                mainMenu.MenuStartup();
                const int MAIN_GAME = 0;
                const int TUTORIAL = 1;
                const int CREDITS = 2;
                const int EXIT = 3;
                int menuSelect = mainMenu.GetSelectedMenuChoice();

                switch (menuSelect)
                {
                    case MAIN_GAME:
                        Console.ForegroundColor = ConsoleColor.Red;
                        MediaController.mainMenuMusic.Stop();

                        mainGame.BeginNarrative();

                        

                        MediaController.mainMenuMusic.PlayLooping();

                        break;
                    case TUTORIAL:
                        tutorial.BeginNarrative();
                        MediaController.mainMenuMusic.Stop();
                        MediaController.mainMenuMusic.PlayLooping();

                        break;
                    case CREDITS:
                        Console.WriteLine("\n");
                        ShowCredits();
                        break;
                    case EXIT:
                        Environment.Exit(0);
                        break;

                }
            }
            



            player.currentLocation = AllRoomObjects.GiveRoom("LoungeRoomID");
            Console.WriteLine(player.currentLocation.roomID);
            player.currentLocation.GiveDescription();


            player.PlayerAction();

            
        }

        void SetGame()
        {
            allRoomObjects.CreateRooms();
            allCharacterObjects.CreateCharacters();
            allItemObjects.CreateItems();
            allDoorObjects.CreateDoors();

            foreach (Room room in AllRoomObjects.rooms)
            {
                room.northRoom = AllRoomObjects.GiveRoom(room.northRoomID);
                room.southRoom = AllRoomObjects.GiveRoom(room.southRoomID);
                room.eastRoom = AllRoomObjects.GiveRoom(room.eastRoomID);
                room.westRoom = AllRoomObjects.GiveRoom(room.westRoomID);

                room.northDoor = AllDoorObjects.GiveDoor(room.northDoorID);
                room.southDoor = AllDoorObjects.GiveDoor(room.southDoorID);
                room.eastDoor = AllDoorObjects.GiveDoor(room.eastDoorID);
                room.westDoor = AllDoorObjects.GiveDoor(room.westDoorID);
            }
        }

        void ShowCredits()
        {
            string[] creditsIntro =
            {
                "Game By - Nehemiah Cedillo",
                "Created On - November 8, 2022",
                "For - Midterm Project, Programming 101 at Columbia Chicago College, FA 2022",
                "",
                "-------------------------Credited/Additional Help-------------------------",
                "",
                "Programming Is Fun (http://programmingisfun.com/) - Providing Basics to create an adventure game",
                "Michael Hadley (https://www.youtube.com/watch?v=eBadZxYe6I4) - Adventure game architecture and a menu that uses arrow keys.",
                "Dani Krossng (https://www.youtube.com/watch?v=t2SPg6IuT3k) - Tutorial providing an understanding about Classes and Objects",
                "Dani Krossng (https://youtu.be/cp19RhiHHok) - Tutorial providing an understanding about Creating Namespaces",
                "Dani Krossng (https://youtu.be/i6n_fwLTKIc) - Tutorial providing an understanding about Arrays",
                "AvetisCodes (https://www.youtube.com/watch?v=86ymhq54V5k) - Tutorial for understanding Static and non-Static",
                "Tim Corey, aka IAmTimCorey (https://www.youtube.com/watch?v=9mUuJIKq40M) - Tutorial for file systems and directories",
                "Caleb Curry (https://www.youtube.com/watch?v=DG75QLJAty0) - Understanding jagged arrays and 2D arrays",
                "Michael Hadley (https://www.youtube.com/watch?v=wAYN2BABnG0) - Tutorial around Sounds and soundplaying",
                "Vere Miller (https://www.youtube.com/watch?v=GNyeojGBqmQ) - Tutorial for understanding Timers",
                "Celtx (https://www.celtx.com/) - An Online scriptwriting program, Free Trial used.",
                "Indy Mogul (https://www.youtube.com/watch?v=XZszextv6yE) - Tutorial around the basics of script-writing (Not programming related",
                "Indy Mogul (https://www.youtube.com/watch?v=403el1Tzk8E) - More advanced screenplay script writing",
                "Dmitry Shub (Teacher from FA22-PROG 101-01) - Teaching about programming 101 and providing basics about programming in C#"
            };

            Console.ForegroundColor = ConsoleColor.White;

            foreach (string line in creditsIntro)
            {
                CreateSpacesForCenteredString(line);
                foreach(char letter in line)
                {
                    if (letter == '(')
                    {//Color links or other information within paranthesis.
                        Console.ForegroundColor = ConsoleColor.Cyan;
                    }
                    else if (letter == ')')
                    {//Return to normal color
                        Console.ForegroundColor = ConsoleColor.White;
                    }
                    else if (letter == '-')
                    {//Highlight how they provided help
                        Console.ForegroundColor = ConsoleColor.Yellow;
                    }


                    Console.Write(letter);
                }

                //Reset to standard color
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine();
            }


            Console.WriteLine("\n\n");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(CenterString("Press Enter to continue"));
            Console.ResetColor();
            Console.ReadLine();
        }

        void CreateSpacesForCenteredString(string _string)
        {
            for (int i = 0; i < (Console.WindowWidth / 2) - (_string.Length / 2); i++)
            {
                Console.Write(" ");
            }
        }
        string CenterString(string _string)
        {
            string centeredString = "";

            for (int i = 0; i < (Console.WindowWidth / 2) - (_string.Length / 2); i++)
            {
                centeredString += " ";
            }
            centeredString += _string;
            return centeredString;
        }


    }
}
