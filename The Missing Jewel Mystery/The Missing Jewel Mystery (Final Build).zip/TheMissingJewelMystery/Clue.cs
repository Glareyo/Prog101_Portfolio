﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Threading.Tasks;

namespace TheMissingJewelMystery_Prototype1
{
    internal class Clue
    {
        public string clueID;
        public string clueSummary;

        public string clueName;
        
        public string locationFound;
        public string personStatementBy;

        public string clueType;

        const string OBSERVATION = "Observation";
        const string STATEMENT = "Statement";


        public Clue(Item _item)
        {
            clueID = _item.itemID + "clueID";
            clueName = _item.name + " Clue";
            clueSummary = _item.clueSummary;
            locationFound = _item.location.name;

            

            clueType = OBSERVATION;
        }

        public Clue(Character _character, Question _question)
        {
            clueID = _question.questionID + "clueID";
            personStatementBy = _character.name;
            clueName = _question.questionPrompt + " Clue";
            clueSummary = _question.clueSummary;

            clueType = STATEMENT;
        }

        public void InitClueInfo()
        {
            if (clueType == STATEMENT) RevealClueInfo_Character();
            else RevealClueInfo_Item();
        }

        void RevealClueInfo_Item()
        {

        }

        void RevealClueInfo_Character()
        {
            Console.Write($"{STATEMENT} by: ");
            ObjectColors.PersonColor(personStatementBy);
            Console.WriteLine();
            Console.WriteLine($"{clueName}: {clueSummary}");
        }
    }
}   
