﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TheMissingJewelMystery;

namespace TheMissingJewelMystery_Prototype1
{
    internal class Room
    {
        public string roomID;
        public string name;
        public string description;

        public string northRoomID;
        public string southRoomID;
        public string eastRoomID;
        public string westRoomID;

        public string northDoorID;
        public string southDoorID;
        public string eastDoorID;
        public string westDoorID;


        public Room northRoom; //Create other directions if this works
        public Room southRoom;
        public Room eastRoom;
        public Room westRoom;

        public Door northDoor;
        public Door southDoor;
        public Door eastDoor;
        public Door westDoor;


        
        public Room(string _roomID, string _name, string _description, string _northRoomID, string _southRoomID, string _eastRoomID, string _westRoomID, string _northDoorID, string _southDoorID, string _eastDoorID, string _westDoorID)
        {
            this.roomID = _roomID;
            this.name = _name;
            this.description = _description;
            this.northRoomID = _northRoomID;
            this.southRoomID = _southRoomID;
            this.eastRoomID = _eastRoomID;
            this.westRoomID = _westRoomID;
            this.northDoorID = _northDoorID;
            this.southDoorID = _southDoorID;
            this.eastDoorID = _eastDoorID;
            this.westDoorID = _westDoorID;
        }

        public void GiveDescription()  //Write the description of the room 
        {
            ObjectColors.RoomColor(name);

            Console.WriteLine();
            Console.WriteLine(description);
            Console.WriteLine("\n");

            CharactersInRoom();
            ItemsInRoom();
            DoorsInRoom();
            RoomsNextDoor();
            VanInRoom();

            string S = "To the South,";
            string N = "To the North,";
            string E = "To the East,";
            string W = "To the West,";
            

            
            PrintDirections(N, northDoor, northRoom);
            PrintDirections(S, southDoor, southRoom);
            PrintDirections(E, eastDoor, eastRoom);
            PrintDirections(W, westDoor, westRoom);
            
            
        }
        void PrintDirections(string _directionPrompt, Door _door, Room _room)
        {
            if (_door.doorID == " ")
            {
                Console.Write($"{_directionPrompt} it leads to the ");
                ObjectColors.RoomColor(_room.name + "\n");
            }
            else if ((_door.isClear == true) || (_door.isOpen == true))
            {
                Console.Write($"{_directionPrompt} there is the {_door.name} leading to the ");
                ObjectColors.RoomColor(_room.name + "\n");
            }
                
            else Console.WriteLine($"{_directionPrompt} there is the {_door.name}");
        }
        void RoomsNextDoor()
        {
            foreach (Room room in AllRoomObjects.rooms)
            {
                if (this.northRoomID == room.roomID) northRoom = room;
                if (this.southRoomID == room.roomID) southRoom = room;
                if (this.eastRoomID == room.roomID) eastRoom = room;
                if (this.westRoomID == room.roomID) westRoom = room;

            }
        }
        void DoorsInRoom()
        {
            foreach (Door door in AllDoorObjects.doors)
            {
                if (this.northDoorID == door.doorID) northDoor = door;
                if (this.southDoorID == door.doorID) southDoor = door;
                if (this.eastDoorID == door.doorID) eastDoor = door;
                if (this.westDoorID == door.doorID) westDoor = door;

            }
        }
        void CharactersInRoom()
        {
            foreach (Character character in AllCharacterObjects.allCharacters)
            {
                if (character.location.roomID == this.roomID)
                {
                    ObjectColors.PersonColor(character.name);
                    Console.WriteLine($" is here, {character.currentState}");
                }
            }
        }
        void ItemsInRoom()
        {
            foreach (Item item in AllItemObjects.items)
            {
                if (item.location.roomID == this.roomID)
                {
                        Console.Write("There is a/an ");
                        ObjectColors.ItemColor(item.name);
                        Console.WriteLine($" here, {item.currentState}");

                }
                
                
                
            }
        }

        void VanInRoom()
        {
            if (PoliceVan.location.roomID == this.roomID)
            {
                Console.Write("The ");
                ObjectColors.PoliceVanName();
                Console.WriteLine($" is here, {PoliceVan.currentState}");
            }
        }
        

        
    }
}
