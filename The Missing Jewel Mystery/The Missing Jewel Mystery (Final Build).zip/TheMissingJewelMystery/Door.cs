﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheMissingJewelMystery_Prototype1
{
    class Door
    {
        public string doorID;
        public string name;
        public string description;
        public string openingDescription;
        public string closingDescription;
        public string unlockingDescription;
        public string lockingDescription;


        public bool isDoor;
        public bool lockable;
        public bool openable;
        public bool isLocked;
        public bool isOpen;
        public bool isClear;
        
        public Item key;

        public Door(string _doorID, string _name, string _description,string _openingDescription,string _closingDescription, string _unlockingDescription, string _lockingDescription, bool _isDoor, bool _lockable, bool _openable, bool _isLocked, bool _isOpen, bool _isClear, string _key)
        {
            this.doorID = _doorID;
            this.name = _name;
            this.description = _description;
            this.openingDescription = _openingDescription;
            this.closingDescription = _closingDescription;
            this.unlockingDescription = _unlockingDescription;
            this.lockingDescription = _lockingDescription;
            this.isDoor = _isDoor;
            this.lockable = _lockable;
            this.openable = _openable;
            this.isLocked = _isLocked;
            this.isOpen = _isOpen;
            this.isClear = _isClear;

            this.key = AllItemObjects.GiveItem(_key);
        }

        public void ChangeLockState(Item _key)
        {
            if (key == _key)
            {
               if (isLocked == true)
               {
                   Console.WriteLine(unlockingDescription);
                   isLocked = false;
               }
                else if (lockable == true)
                {
                    Console.WriteLine(lockingDescription);
                    isLocked = true;
                }

                Console.Write("The door is now ");
                if (isLocked)
                {
                    Console.ForegroundColor = ConsoleColor.Red;
                    Console.WriteLine("LOCKED");
                }
                else
                {
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("UNLOCKED");
                }

            }
            else Console.WriteLine("This is not the right item");
            
        }
        public void ChangeOpenState()
        {
            if (openable == true)
            {
                if (isOpen) //Close door
                {
                    Console.WriteLine(closingDescription);
                    isOpen = false;
                    Console.Write("The door is now ");
                    Console.ForegroundColor = ConsoleColor.Yellow;
                    Console.WriteLine("CLOSED");
                }
                else
                {
                    if (isLocked)
                    {
                        Console.Write($"The {name} is currently ");
                        Console.ForegroundColor = ConsoleColor.Red;
                        Console.WriteLine("LOCKED");
                        Console.ResetColor();
                    }
                    else
                    {
                        Console.WriteLine(openingDescription);
                        isOpen = true;
                        Console.Write("The door is now ");
                        Console.ForegroundColor = ConsoleColor.Green;
                        Console.WriteLine("OPEN");
                    }
                }
               
                Console.ResetColor();
            }
            else
            {
                Console.WriteLine("This door cannot be opened...");
            }
        }
    }
}
