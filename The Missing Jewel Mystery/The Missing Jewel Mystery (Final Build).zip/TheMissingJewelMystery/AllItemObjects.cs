﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Linq.Expressions;

namespace TheMissingJewelMystery_Prototype1
{
    class AllItemObjects
    {
        static public List<Item> items = new List<Item>();


        string targetFolder = "AllItemsFolder";
        
        string directoryPath;
        string[] InfoFiles;

        


        

        void SetDirectory()
        {
            directoryPath = Directory.GetCurrentDirectory();
            directoryPath = Path.Combine(directoryPath, targetFolder);
            InfoFiles = Directory.GetFiles(directoryPath);
        }
        public void CreateItems()
        {

            SetDirectory();
            //Get number of item files in file.
            int numberOfItems = InfoFiles.Length;
            Item[] itemsArray = new Item[numberOfItems];
            
            int itemNum = 0;

            foreach (string file in InfoFiles)
            {
                string[] textLineInfo = File.ReadAllLines(file);
                string itemID = "0";
                string name = "1";
                string description = "2";
                string interactDescription = "3";
                string clueSummary = "4";
                string roomIDInfo = "5";
                string currentState = "6";
                string sizeInfo = "7";
                string canPickUpInfo = "8";

                string isContainerInfo = "9";
                string isLockedInfo = "10";
                string unlockingDescription = "11";
                string keyItemID = "12";


                List<string> containedItemsID = new List<string>();

                string[] requiredInfo = { itemID, name, description, interactDescription, clueSummary, roomIDInfo, currentState, sizeInfo, canPickUpInfo, isContainerInfo, isLockedInfo, unlockingDescription, keyItemID };
                int number = 0;

                int size;
                bool canPickUp = false;
                Room location = null;
                bool isContainer = false;
                bool isLocked = false;




                for (int i = 0; i < textLineInfo.Length; i++)
                {
                    if (textLineInfo[i][0] != '-')
                    {
                        if (number >= requiredInfo.Length)
                        {
                            containedItemsID.Add(textLineInfo[i]);
                        }
                        else
                        {
                            requiredInfo[number] = textLineInfo[i];
                            number++;
                        }

                    }
                }
                
                
                
                itemID = requiredInfo[0];
                name = requiredInfo[1];
                description = requiredInfo[2];
                interactDescription = requiredInfo[3];
                clueSummary = requiredInfo[4]; 
                roomIDInfo = requiredInfo[5];
                currentState = requiredInfo[6];
                sizeInfo = requiredInfo[7]; 
                canPickUpInfo = requiredInfo[8];

                //Container information
                isContainerInfo = requiredInfo[9];
                isLockedInfo = requiredInfo[10];
                unlockingDescription = requiredInfo[11];
                keyItemID = requiredInfo[12];

                //Set bools
                location = AllRoomObjects.GiveRoom(roomIDInfo);
                size = Convert.ToInt32(sizeInfo);
                canPickUp = Convert.ToBoolean(canPickUpInfo);
                isContainer = Convert.ToBoolean(isContainerInfo);
                isLocked = Convert.ToBoolean(isLockedInfo);

                itemsArray[itemNum] = new Item( itemID,  name,  description,  interactDescription,  clueSummary,  location,  currentState,  size,  canPickUp,  isContainer,  isLocked,  unlockingDescription,  keyItemID,  containedItemsID);
                items.Add(itemsArray[itemNum]);

                
                itemNum++;
            }

            SetKeyItemsForContainerItems();
            SetContainedItemsForContainerItems();
        }



        void SetContainedItemsForContainerItems()
        {
            foreach (Item item in items)
            {
                foreach(string itemID in item.containedItemsID)
                {
                    if(itemID !=" ")
                    {
                        AllItemObjects.GiveItem(itemID).location = AllRoomObjects.GiveRoom(" ");
                        item.containedItems.Add(AllItemObjects.GiveItem(itemID));
                    }
                }
            }
        }
        void SetKeyItemsForContainerItems()
        {
            foreach (Item item in items)
            {
                if (item.keyItemID != "")
                {
                    item.key = AllItemObjects.GiveItem(item.keyItemID);
                }
            }
        }
        static public Item GiveItem(string _itemID)
        {
            foreach (Item item in items)
            {
                if (_itemID == item.itemID)
                {
                    return item;
                }
            }
            return null;
        }


    }
}
