﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheMissingJewelMystery_Prototype1
{
    class Item
    {
        public Room location;
        public Clue clue;

        public string itemID;
        public string name;
        public string description;
        public string interactDescription;
        public string clueSummary;
        public string currentState;

        public int size;
        public bool canPickUp;


        public bool isContainer;
        public bool isLocked;
        public string unlockingDescription;
        public string keyItemID;
        public List<string> containedItemsID = new List<string>();


        public Item key;
        public List<Item> containedItems = new List<Item>();
        
        public Item(string _itemID, string _name, string _description, string _interactDescription, string _clueSummary, Room _location, string _currentState, int _size, bool _canPickUp, bool _isContainer, bool _isLocked, string _unlockingDescription, string _keyItemID, List<string> _containedItemsID)

        {
            this.itemID = _itemID;
            this.name = _name;
            this.description = _description;
            this.interactDescription = _interactDescription;
            this.clueSummary = _clueSummary;
            this.location = _location;
            this.currentState = _currentState;

            this.size = _size;
            this.canPickUp = _canPickUp;

            this.isContainer = _isContainer;
            this.isLocked = _isLocked;
            this.unlockingDescription = _unlockingDescription;
            this.keyItemID = _keyItemID;
            this.containedItemsID = _containedItemsID;

            clue = new Clue(this);
        }

        public void UnlockContainer(Item _key)
        {
            if (_key == this.key)
            {
                if (isLocked)
                {
                    Console.WriteLine(unlockingDescription);
                    Console.Write("The ");
                    ObjectColors.ItemColor(this.name);
                    Console.Write("is now ");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write("UNLOCKED\n");
                    Console.ResetColor();
                    isLocked = false;
                }
                else
                {
                    Console.Write("The ");
                    ObjectColors.ItemColor(this.name);
                    Console.Write("is ALREADY ");
                    Console.ForegroundColor = ConsoleColor.Green;
                    Console.Write("UNLOCKED\n");
                    Console.ResetColor();
                }
                
            }
            else Console.WriteLine("This is not the right item.");            
        }
        public void OpenContainer()
        {
            if (isLocked)
            {
                ContainerIsLockedPrompt();
            }
            else
            {
                RevealContainedItems();
            }
        }
        public bool PlaceItemInside(Item _item)
        {
            if (isLocked)
            {
                ContainerIsLockedPrompt();
            }
            else if (_item.size > this.size)
            {
                Console.Write("The ");
                ObjectColors.ItemColor(_item.name);
                Console.Write(" is ");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("TOO LARGE");
                Console.ResetColor();
            }
            else if (_item.size + GetContainedItemsTotalSize() > this.size)
            {
                Console.Write("There is ");
                Console.ForegroundColor = ConsoleColor.Yellow;
                Console.Write("NOT ENOUGH ROOM");
                Console.ResetColor();
                Console.Write(" for the ");
                ObjectColors.ItemColor(_item.name);
                Console.WriteLine();
            }
            else
            {
                _item.location = AllRoomObjects.GiveRoom(" ");
                Console.Write("The ");
                ObjectColors.ItemColor(_item.name);
                Console.Write(" has been ");
                Console.ForegroundColor = ConsoleColor.Red;
                Console.WriteLine("PLACED");
                Console.ResetColor();

                containedItems.Add(_item);
                return true;
            }
            return false;

        }
        public void RemoveItemInside(Item targetItem)
        {
            if (isLocked)
            {
                ContainerIsLockedPrompt();
            }
            else
            {
                Console.Write("The ");
                ObjectColors.ItemColor(targetItem.name);
                Console.WriteLine(" has been removed.");
                containedItems.Remove(targetItem);
            }
        }

        int GetContainedItemsTotalSize()
        {
            int totalSize = 0;
            foreach (Item item in containedItems)
            {
                totalSize += item.size;
            }

            return totalSize;
        }
        void RevealContainedItems()
        {
            Console.Write("The ");
            ObjectColors.ItemColor(this.name);

            if (containedItems.Count == 0)
            {
                Console.WriteLine(" does not contain anything.");
            }
            else
            {
                Console.WriteLine(" contains: ");

                foreach (Item item in containedItems)
                {
                    ObjectColors.ItemColor(item.name);
                    Console.WriteLine();
                }
                Console.ResetColor();
            }
        }
        
        void ContainerIsLockedPrompt()
        {
            Console.Write("The ");
            ObjectColors.ItemColor(this.name);
            Console.Write(" is ");
            Console.ForegroundColor = ConsoleColor.Red;
            Console.WriteLine("LOCKED");
            Console.ResetColor();
        }
    }
}
