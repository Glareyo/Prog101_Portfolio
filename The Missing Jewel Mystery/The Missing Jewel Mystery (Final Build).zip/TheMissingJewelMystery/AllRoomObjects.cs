﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Xml.Linq;

namespace TheMissingJewelMystery_Prototype1
{
    class AllRoomObjects
    {
        string targetFolder = "AllRoomsFolder";
        string directoryPath;
        string[] InfoFiles;
        
        static public List<Room> rooms = new List<Room>();
        
        
        
        void SetDirectory()
        {
            directoryPath = Directory.GetCurrentDirectory();
            directoryPath = Path.Combine(directoryPath, targetFolder);
            InfoFiles = Directory.GetFiles(directoryPath);
        }
        public void CreateRooms()
        {
            SetDirectory();
            int numberOfRooms = InfoFiles.Length;
            Room[] AllRoomsArray = new Room[numberOfRooms];
            int roomNumber = 0;

            string roomIDInfo = "0";
            string nameInfo = "1";
            string descriptionInfo = "2";
            string northIDInfo = "3";
            string southIDInfo = "4";
            string eastIDInfo = "5";
            string westIDInfo = "6";
            string northDoorIDInfo = "7";
            string southDoorIDInfo = "8";
            string eastDoorIDInfo = "9";
            string westDoorIDInfo = "10";

            string[] requiredInfo = { roomIDInfo, nameInfo, descriptionInfo, northIDInfo, southIDInfo, eastIDInfo, westIDInfo, northDoorIDInfo, southDoorIDInfo, eastDoorIDInfo, westDoorIDInfo };

            string roomID;
            string name;
            string description;
            string northRoomID;
            string southRoomID;
            string eastRoomID;
            string westRoomID;
            string northDoorID;
            string southDoorID;
            string eastDoorID;
            string westDoorID;

            foreach (string file in InfoFiles)
            {
                int number = 0;
                string[] textLineInfo = File.ReadAllLines(file);
                for (int i = 0; i < textLineInfo.Length; i++)
                {
                    try
                    {
                        if ((textLineInfo[i][0] != '-') || (textLineInfo[i][0] == ' '))
                        {
                            requiredInfo[number] = textLineInfo[i];
                            number++;
                        }
                    }
                    catch
                    {
                        Console.BackgroundColor = ConsoleColor.Red;
                        Console.ForegroundColor = ConsoleColor.White;
                        Console.WriteLine($"ERROR WITH: {textLineInfo[i]} at sector {i+1}, file name {file}");
                        Console.ResetColor();
                    }
                    
                }
                //Set Object Strings
                roomID = requiredInfo[0];
                name = requiredInfo[1];
                description = requiredInfo[2];
                northRoomID = requiredInfo[3];
                southRoomID = requiredInfo[4];
                eastRoomID = requiredInfo[5];
                westRoomID = requiredInfo[6];
                northDoorID = requiredInfo[7];
                southDoorID = requiredInfo[8];
                eastDoorID = requiredInfo[9];
                westDoorID = requiredInfo[10];

               //Add to list
               AllRoomsArray[roomNumber] = new Room(roomID,name,description,northRoomID,southRoomID,eastRoomID,westRoomID,northDoorID,southDoorID,eastDoorID,westDoorID);
               rooms.Add(AllRoomsArray[roomNumber]);
               roomNumber++;
            }
        }


       

        static public Room GiveRoom(string _roomID)
        {
            foreach (Room room in rooms)
            {
                if (room.roomID == _roomID)
                {
                    return room;
                }
            }
            return null;
        }
    }
}
