﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using TheMissingJewelMystery;

namespace TheMissingJewelMystery_Prototype1
{
    static class ObjectColors
    {
        // Use to color code objects.
        
        public static void ItemColor(string itemName)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(itemName);
            Console.ResetColor();
        }
        public static void RoomColor(string roomName)
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write(roomName);
            Console.ResetColor();
        }
        public static void PersonColor(string characterName)
        {
            Console.ForegroundColor = ConsoleColor.Cyan;
            Console.Write(characterName);
            Console.ResetColor();
        }
        public static void DoorColor(string doorName)
        {
            Console.ForegroundColor = ConsoleColor.White;
            Console.Write(doorName);
            Console.ResetColor();
        }
        public static void PoliceVanName()
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
            Console.Write(PoliceVan.name);
            Console.ResetColor();
        }

    }
}
