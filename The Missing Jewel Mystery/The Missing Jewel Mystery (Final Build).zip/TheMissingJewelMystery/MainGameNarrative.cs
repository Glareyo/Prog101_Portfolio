﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Timers;
using TheMissingJewelMystery;

namespace TheMissingJewelMystery_Prototype1
{
    class MainGameNarrative
    {
        Room startingLocation = AllRoomObjects.GiveRoom("RoundAboutRoomID");
        Player player;
        Room EndingRoom = AllRoomObjects.GiveRoom("OutsideTheGemMansionRoomID");
        Item jewel = AllItemObjects.GiveItem("TheMissingJewelItemID");
        


        string[] correctSuspects =
        {
            "Adam",
            "Jackson",
            "Sofia",
            "Brent",
            "Nelson",
            "Stanley"
        };
        
        int minutes = 0;
        int seconds = 0;
        Timer gameTime = new Timer(1000);
        public MainGameNarrative(Player _player)
        {
            player = _player;

        }

        public void BeginNarrative()
        {
            Console.Clear();
            player.inventory.Clear();

            Introduction();
            FirstScene();


            StartingNarrative();
        }
        
        
        
        
        void Introduction()
        {
            int musicPhase = 0;
            Timer musicIntro = new Timer();
            


            MediaController.jazzNoir.PlayLooping();
            bool musicIsPlaying = false;
            while(!musicIsPlaying)
            {
                if (MediaController.jazzNoir.IsLoadCompleted == true) musicIsPlaying=true;
            }    


            musicIntro.Elapsed += musicIntro_elapsed;
            musicIntro.Interval = 700;
            musicIntro.Enabled = true;
            musicIntro.AutoReset = false;
            musicIntro.Start();

            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine("\n\n\n\n");
            void musicIntro_elapsed(object sender, ElapsedEventArgs e)
            {
                if (musicPhase == 0)
                {
                    Console.WriteLine(CenterString("A midterm Project"));
                    musicIntro.Interval = 1000;
                    musicIntro.Start();
                    musicPhase++;
                }
                else if (musicPhase == 1)
                {
                    Console.WriteLine(CenterString("For Programming 101, FA2022"));
                    musicIntro.Interval = 1100;
                    musicIntro.Start();
                    musicPhase++;

                }
                else if (musicPhase == 2)
                {
                    Console.WriteLine(CenterString("By Nehemiah Cedillo"));
                    musicIntro.Interval = 2200;
                    musicIntro.Start();
                    musicPhase++;
                }
                else if (musicPhase == 3) // Clear
                {
                    Console.Clear();
                    musicIntro.Interval = 5000;
                    musicIntro.Start();
                    musicPhase++;
                }
                else if (musicPhase == 4)
                {
                    musicPhase++;
                    musicIntro.Stop();
                }

            }
            while (true)
            {
                if (musicPhase == 5) break;
            }



            Console.WriteLine("\n");
            Console.BackgroundColor = ConsoleColor.DarkGray;
            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine(MediaController.TitleCard);
            Console.WriteLine("\n");
            Console.ResetColor();

        }

        void FirstScene()
        {

            Continue();
            Console.Clear();
            Console.WriteLine("\n\n\n\n\n");

            Narrate("All the rain last night made the streets a bit slippery, but nonetheless drivable.");
            
            
            Continue();
            Console.Clear();
            Console.WriteLine("\n\n\n\n\n");

            Narrate("The mansion is up ahead. Towering over the giant iron fence that surrounds it.");


            Continue();
            Console.Clear();
            Console.WriteLine("\n\n\n\n\n");

            Narrate("The gates open slowly up ahead, the rusty creaking of the hinges echoing in the air.");


            Continue();
            Console.Clear();
            Console.WriteLine("\n\n\n\n\n");
            Narrate("Driving into the roundabout, you get out of the vehicle with Michelle, who takes post by it.");

            
            Continue();
            Console.Clear();
            Console.WriteLine("\n\n\n\n\n");

            
            Narrate("As you walk down the roundabout, a tall man in a butler attire approaches you...");


            Continue();
            Console.Clear();
            Console.WriteLine("\n\n\n\n\n");

            Dialog("Butler", "Hello Sir and Madame\n");
            Dialog("Butler", "It is perfect timing that you've arrived\n");
            Dialog("Butler", "Mr.Gregory Gem and Mrs.Penelope Gem have been in terrible distraught over this heinous incident.\n");
            Dialog("Butler", "Please, you must find the jewel.");


            Continue();
            Console.Clear();
            Console.WriteLine("\n\n\n\n\n");

            Dialog(player.name, "I'll do my best.");

            Continue();
            Console.Clear();
            Console.WriteLine("\n\n\n\n\n");

            Dialog("Butler", "Thank you...");
            Console.WriteLine();
            Narrate("Swiftly, the butler turns around and walks back through the massive doors leading to the house.");

            Continue();
            Console.Clear();
            Console.WriteLine("\n\n\n\n\n");

            Dialog("Michelle", "I'll stand by vehicle.");
            Dialog("Michelle", "If you suspect anybody, come back to the van and we'll jot their name down.");


            Continue();
            Console.Clear();
            Console.WriteLine("\n\n\n\n\n");

            Narrate_Highlight("It is up to you to"," solve ", "this mystery.");
            Narrate_Highlight("Find out"," who the thief, or thieves"," are.");
            Narrate_Highlight("And find"," the Missing Jewel",".");

            Console.WriteLine("\n\n\n\n\n");

            Narrate_Yellow("Good luck...");

            Continue();
            Console.Clear();


        }
        void StartingNarrative()
        {
            bool finishGame = false;
            bool jewelDiscovered = false;


            //Helped recieved via from youtube video https://www.youtube.com/watch?v=GNyeojGBqmQ by Vere Miller
            //In terms of understanding timers.

            /*Code was not directly copied.*/
            gameTime.Elapsed += gameTime_Elapsed;
            gameTime.Enabled = true;
            gameTime.AutoReset = true;
            gameTime.Start();
            /*Code was not directly copied.*/


            player.currentLocation = startingLocation;
            while (!finishGame)
            {
                player.PlayerAction();

                if (player.inventory.Contains(jewel) && jewelDiscovered == false)
                {
                    jewelDiscovered = true;
                    Narrate_Yellow("You have found The Missing Jewel!");
                    Narrate_Highlight("Keep the jewel either ", "in your inventory or place it in the van.", "");
                    Continue();
                }




                if (player.currentLocation == EndingRoom)
                {
                    finishGame = ExitTheMansionMenu();
                }
            }

            FinalConclusionScene();
        }
       


        void FinalConclusionScene()
        {

            MediaController.finalSceneMusic.Play();

            string[] timeItTookNarrations = { "very quick", "thorough", "grueling" };
            int timeItTookNarrationIndex = 0;
            if (minutes < 5) timeItTookNarrationIndex = 0;
            else if (minutes < 15) timeItTookNarrationIndex = 1;
            else timeItTookNarrationIndex = 2;

            //Conclude investigation
            Narrate($"After a {timeItTookNarrations[timeItTookNarrationIndex]} investigation, a conclusion has been made.");

            Continue();

            //Display who the player suspected.
            if (PoliceVan.suspects.Count <= 0)
            {
                Narrate("No arrests have been made.");
                Continue();
                Console.Clear();
            }

            else
            {
                Narrate("With the sirens and the lights lighting up the now setting sky, the suspected suspects are walking out.");
                Narrate("Based on your investigation, you've decided to arrest: ");

                foreach (string suspect in PoliceVan.suspects)
                {
                    ObjectColors.PersonColor(CenterString(suspect));
                    Console.WriteLine();
                }

                Continue();
                Console.Clear();
                int numberOfSuspects = PoliceVan.suspects.Count;
                int numberOfCorrectSuspects = 0;
                foreach (string suspect in correctSuspects)
                {
                    if (PoliceVan.suspects.Contains(suspect)) numberOfCorrectSuspects++;
                }
                Narrate("During the court proceedings and the evidence gathered, it was then concluded...");
                if (numberOfCorrectSuspects <= 0) Narrate_Highlight($"Out of {numberOfSuspects} suspects, ", "none of them were the correct ones", "");
                else if (numberOfSuspects > numberOfCorrectSuspects) Narrate_Highlight($"Out of {numberOfSuspects} suspects, only ", $"{numberOfCorrectSuspects} of them ", "were the correct suspects.");
                else if (numberOfCorrectSuspects == 6) Narrate_Highlight("", "All ", $"{numberOfCorrectSuspects} have been found guilty.");
                else if (numberOfCorrectSuspects == numberOfSuspects) Narrate_Highlight($"All {numberOfSuspects} were found guilty, but", " there are others involved...", "");
                Console.WriteLine();

                if (numberOfCorrectSuspects == 6)
                {
                    Narrate_Yellow($"Well done, Detective {player.name}");

                    Continue();
                    Console.Clear();

                    if (PoliceVan.containedItems.Contains(jewel) == false && player.inventory.Contains(jewel) == false) Narrate_Highlight("", "However...", "");
                }
                else if (numberOfCorrectSuspects > 0)
                {

                    Continue();
                    Console.Clear();
                    if (PoliceVan.containedItems.Contains(jewel) == false && player.inventory.Contains(jewel) == false) Narrate_Highlight("", "However...", "");
                    
                }
                else
                {

                    Continue();
                    Console.Clear();
                }
            }




            //How many suspects were the right ones.


            Console.WriteLine("\n\n\n\n\n\n\n\n\n");



            //Display if the player has found the jewel.
            if (PoliceVan.containedItems.Contains(jewel) == false && player.inventory.Contains(jewel) == false)
            {
                Narrate_Highlight("The Missing Jewel is still yet to be ", "found", "...");
            }
            else if (PoliceVan.containedItems.Contains(jewel) == true || player.inventory.Contains(jewel) == true)
            {
                Narrate_Highlight("The Missing Jewel has been", " found ", ", and is now returned to the Gem Family.");
            }



            Continue();


            Narrate($"Total Time: {minutes} minutes and {seconds} seconds");
            Narrate_Highlight("To replay the game, it would be best to ", "restart", " the application");

            Continue();
        }





        //Helped recieved via from youtube video https://www.youtube.com/watch?v=GNyeojGBqmQ by Vere Miller
        //In terms of understanding timers.

        /*Code was not directly copied.*/
        void gameTime_Elapsed(object sender, ElapsedEventArgs e)
        {
            if (seconds == 60)
            {
                seconds = 0;
                minutes += 1;
            }
            else seconds += 1;
        }
        /*Code was not directly copied.*/











        bool ExitTheMansionMenu()
        {
            

            string[] MenuPrompts =
            {
                "NO",
                "YES"
            };
            int currentChoice = 0;


            while (true)
            {
                Console.Clear();
                Narrate("You are about to leave the Mansion.");
                Narrate("By leaving, all suspects that you have listed will be detained and arrested.");
                Narrate("Do you wish to continue?");

                Console.WriteLine();

                //Prompt Inputs
                Console.ForegroundColor = ConsoleColor.Green;


                Console.WriteLine("\n");
                Console.ResetColor();

                for (int i = 0; i < MenuPrompts.Length; i++)
                {


                    if (currentChoice == i)
                    {
                        foreach (char c in CenterString(MenuPrompts[i]))
                        {
                            if (c != ' ')
                            {
                                Console.BackgroundColor = ConsoleColor.White;
                                Console.ForegroundColor = ConsoleColor.Black;
                            }
                            Console.Write(c);
                        }
                    }
                    else Console.Write(CenterString(MenuPrompts[i]));
                    Console.WriteLine();
                    Console.ResetColor();
                }


                // Using https://learn.microsoft.com/en-us/dotnet/api/system.consolekeyinfo.key?view=net-6.0 as a reference for learning keys.

                string keyPressed = Console.ReadKey().Key.ToString();

                string enterKeyString = ConsoleKey.Enter.ToString();
                string upArrowString = ConsoleKey.UpArrow.ToString();
                string downArrowString = ConsoleKey.DownArrow.ToString();


                if (keyPressed == upArrowString)
                {
                    currentChoice--;
                    if (currentChoice < 0) currentChoice = MenuPrompts.Length - 1;
                }
                else if (keyPressed == downArrowString)
                {
                    currentChoice++;
                    if (currentChoice > MenuPrompts.Length - 1) currentChoice = 0;
                }
                else if (keyPressed == enterKeyString)
                {
                    break;
                }
            }
            Console.Clear();
            if (currentChoice == 0)
            {
                player.currentLocation = startingLocation;
                player.currentLocation.GiveDescription();
                return false;
            }
            else if (currentChoice == 1)
            {
                return true;
            }

            return false;
            
        }




        void Continue()
        {
            Console.WriteLine();
            Console.WriteLine(CenterString("Press \"Enter\" to Continue"));
            Console.ReadLine();
        }
        string CenterString(string _string)
        {
            string centeredString = "";

            for (int i = 0; i < (Console.WindowWidth / 2) - (_string.Length / 2); i++)
            {
                centeredString += " ";
            }
            centeredString += _string;
            return centeredString;
        }
        void CreateSpacesForCenteredString(string _string)
        {
            for (int i = 0; i < (Console.WindowWidth / 2) - (_string.Length / 2); i++)
            {
                Console.Write(" ");
            }
        }



        void Narrate_Yellow(string _phrase)
        {
            Console.Write("\n ");
            Console.ForegroundColor = ConsoleColor.Yellow;
            Console.WriteLine(CenterString(_phrase));
            Console.ResetColor();
        }
        void Narrate_Highlight(string _phrase1, string _highlightPhrase2, string _phrase3)
        {
            Console.Write("\n ");

            string entireString = _phrase1 + _highlightPhrase2 + _phrase3;
            CreateSpacesForCenteredString(entireString);


            Console.ForegroundColor = ConsoleColor.Green;
            Console.Write(_phrase1);
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write(_highlightPhrase2);
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(_phrase3);


            Console.ResetColor();
        }
        void Narrate(string _phrase)
        {
            Console.Write("\n ");
            Console.ForegroundColor = ConsoleColor.Green;
            Console.WriteLine(CenterString(_phrase));
            Console.ResetColor();
        }
        void Dialog(string _name, string _phrase)
        {
            string fullString = _name + " : " + _phrase;

            //Use the center string code
            for (int i = 0; i < (Console.WindowWidth / 2) - (fullString.Length / 2); i++)
            {
                Console.Write(" ");
            }


            ObjectColors.PersonColor(_name);
            Console.Write(" : ");

            Console.ForegroundColor = ConsoleColor.White;
            Console.WriteLine($"\"{_phrase}\"");
            Console.ResetColor();
        }
    }
}
