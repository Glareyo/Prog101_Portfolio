﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Media;
using System.Text;
using System.Threading.Tasks;

namespace TheMissingJewelMystery
{
    static class MediaController
    {
        public static string TitleCard = @"
 ┌─────┐ ┌─┐ ┌─┐ ┌────┐    ┌─────────┐ ┌─┐ ┌─────┐ ┌─────┐ ┌─┐ ┌─────┐─┐ ┌──────┐ 
 └─┐ ┌─┘ │ │ │ │ │ ┌──┘    │ ┌─┐ ┌─┐ │ │ │ │ ┌───┘ │ ┌───┘ │ │ │ ┌─┐ │ │ │ ┌────┘ 
   │ │   │ └─┘ │ │ └──┐    │ │ │ │ │ │ │ │ │ └───┐ │ └───┐ │ │ │ │ │ │ │ │ │┌───┐ 
   │ │   │ ┌─┐ │ │ ┌──┘    │ │ │ │ │ │ │ │ └───┐ │ └───┐ │ │ │ │ │ │ │ │ │ │└─┐ │ 
   │ │   │ │ │ │ │ └──┐    │ │ │ │ │ │ │ │ ┌───┘ │ ┌───┘ │ │ │ │ │ │   │ │ └──┘ │ 
   └─┘   └─┘ └─┘ └────┘    └─┘ └─┘ └─┘ └─┘ └─────┘ └─────┘ └─┘ └─┘ └───┘ └──────┘ 
    ┌─┐ ┌────┐ ┌─┐ ┌─┐ ┌─┐ ┌────┐ ┌─┐                                             
    │ │ │ ┌──┘ │ │ │ │ │ │ │ ┌──┘ │ │                                             
    │ │ │ └──┐ │ │ │ │ │ │ │ └──┐ │ │                                             
    │ │ │ ┌──┘ │ │ │ │ │ │ │ ┌──┘ │ │                                             
 ┌──┘ │ │ └──┐ │ └─┘ └─┘ │ │ └──┐ │ └──┐                                          
 └────┘ └────┘ └─────────┘ └────┘ └────┘                                          
 ┌─────────┐ ┌─┐ ┌─┐ ┌─────┐ ┌─────┐ ┌────┐ ┌─────┐ ┌─┐ ┌─┐                       
 │ ┌─┐ ┌─┐ │ │ │ │ │ │ ┌───┘ └─┐ ┌─┘ │ ┌──┘ │ ┌─┐ │ │ │ │ │                       
 │ │ │ │ │ │ │ └─┘ │ │ └───┐   │ │   │ └──┐ │ └─┘ │ │ └─┘ │                       
 │ │ │ │ │ │ └─┐ ┌─┘ └───┐ │   │ │   │ ┌──┘ │ ┌┐ ┌┘ └─┐ ┌─┘                       
 │ │ │ │ │ │   │ │   ┌───┘ │   │ │   │ └──┐ │ │└┐└┐   │ │                         
 └─┘ └─┘ └─┘   └─┘   └─────┘   └─┘   └────┘ └─┘ └─┘   └─┘                         
                                  ┌──────┐                                        
                                  │ ┌──┐ │                                        
                                  │ └──┘ │                                        
                                  └──────┘                                        
";


        public static SoundPlayer jazzNoir = new SoundPlayer("JazzNoir.wav");
        public static SoundPlayer tutorialMusic = new SoundPlayer("Midterm_TutorialMusic.wav");
        public static SoundPlayer mainMenuMusic = new SoundPlayer("MainMenuMusic.wav");
        public static SoundPlayer finalSceneMusic = new SoundPlayer("MidtermProject_FinalScene.wav");

    }
}
