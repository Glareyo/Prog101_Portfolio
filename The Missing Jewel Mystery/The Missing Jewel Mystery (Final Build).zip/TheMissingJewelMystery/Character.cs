﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheMissingJewelMystery_Prototype1
{
    class Character
    {
        public string name;
        public string currentState;
        public string description;
        public Room location;

        public List<Question> questionList = new List<Question>();
        public List<Question> availableQuestions = new List<Question>();


        public Character(string _name, string _currentState, string _description, Room _location, List<Question> _questionList)
        {
            name = _name;
            currentState = _currentState;
            description = _description;
            location = _location;
            questionList = _questionList;
        }
        
        public void RevealAvailableQuestions(List<Clue> collectedClues)
        {
            int questionNumber = 1;
            availableQuestions.Clear();
            foreach (Question question in questionList)
            {
                if (question.IsQuestionAvailable(collectedClues))
                {
                    availableQuestions.Add(question);
                    question.DisplayQuestionPrompt(questionNumber);
                    questionNumber++;
                }
            }
        }

        void GiveDescription()
        {
            //Give the description + currentState of the suspect.
        }
    }
}
