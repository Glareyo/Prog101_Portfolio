﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TheMissingJewelMystery_Prototype1
{
    class Question
    {
        public Question requiredQuestion;
        public Clue requiredClue;
        public string requiredQuestionID;
        public string requiredClueID;
        string requiredClueName; //Set via required Clue ID

        public string answererName; //Which character the question belongs to

        public string questionID;
        public string questionPrompt;
        public string answer;
        
        public Clue clue;
        public string clueSummary;

        bool isAnswered;

        public Question(string _questionID, string _questionPrompt, string _answer, string _requiredQuestionID, string _requiredClueID, string _clueSummary, string _answererName)
        {
            this.isAnswered = false;
            this.questionID = _questionID;
            this.questionPrompt = _questionPrompt;
            this.answer = _answer;
            this.requiredQuestionID = _requiredQuestionID;
            this.requiredClueID = _requiredClueID;
            this.clueSummary = _clueSummary;
            this.answererName = _answererName;

            
            requiredQuestion = null;
            requiredClue = null;
        }


        public bool IsQuestionAvailable(List<Clue> collectedClues)
        {
            if (IsRequiredQuestionAnswered() && IsRequiredClueLogged(collectedClues)) return true;
            else if (isAnswered) return true;
            else return false;
        }
        public void DisplayQuestionPrompt(int _questionNumber)
        {
            Console.ForegroundColor = ConsoleColor.Red;
            Console.Write($" {_questionNumber}");

            Console.Write(") ");
            if (isAnswered) Console.ForegroundColor = ConsoleColor.Gray;
            else
            {
                Console.BackgroundColor = ConsoleColor.DarkRed;
                Console.ForegroundColor = ConsoleColor.White;
            }
            
            Console.Write($"\"{questionPrompt}\"");

            Console.ResetColor();

            if (requiredClueID != " ")
            {
                Console.Write($" --- Using: ");
                Console.BackgroundColor = ConsoleColor.DarkCyan;
                Console.ForegroundColor = ConsoleColor.White;
                Console.WriteLine($"\"{requiredClueName}\"");
                Console.ResetColor();
            }
            else Console.WriteLine();
                
            Console.ResetColor();
        }
        public string GiveAnswer()
        {
            Console.Clear();
            isAnswered = true;
            return this.answer;            
        }



        bool IsRequiredClueLogged(List<Clue> collectedClues)  //Must create and finish Clue Class
        {
            if (requiredClueID == " ")
            {
                return true;
            } 
            else
            {
                foreach (Clue clue in collectedClues)
                {
                    if (clue.clueID == requiredClueID + "clueID")
                    {
                        this.requiredClueName = clue.clueName;
                        return true;
                    }
                }
            }
            return false;
        }
        bool IsRequiredQuestionAnswered()                   
        {
            if (requiredQuestion == null)
            {
                return true;
            }
            else if (requiredQuestion.isAnswered == true) return true;
            else return false;    
        }
        

        
    }
}
